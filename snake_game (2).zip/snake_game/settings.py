"""
settings.py - Game settings management and constants.
Handles resolution, audio, difficulty, language, graphics quality, and persistence.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Tuple, Any, Optional

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
SOUNDS_DIR = os.path.join(ASSETS_DIR, "sounds")
IMAGES_DIR = os.path.join(ASSETS_DIR, "images")
FONTS_DIR = os.path.join(ASSETS_DIR, "fonts")
DATA_DIR = os.path.join(BASE_DIR, "data")

SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
SAVE_FILE = os.path.join(DATA_DIR, "savegame.json")
RECORDS_FILE = os.path.join(DATA_DIR, "records.json")
ACHIEVEMENTS_FILE = os.path.join(DATA_DIR, "achievements.json")
PLAYER_DATA_FILE = os.path.join(DATA_DIR, "player.json")

# ---------------------------------------------------------------------------
# Display / Grid
# ---------------------------------------------------------------------------
DEFAULT_WIDTH = 1280
DEFAULT_HEIGHT = 720
CELL_SIZE = 20
GRID_WIDTH = 40
GRID_HEIGHT = 30

# ---------------------------------------------------------------------------
# Colors (RGB)
# ---------------------------------------------------------------------------
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (128, 128, 128)
DARK_GRAY = (40, 40, 40)
LIGHT_GRAY = (200, 200, 200)
RED = (220, 50, 50)
GREEN = (50, 200, 80)
DARK_GREEN = (20, 140, 50)
BLUE = (50, 100, 220)
YELLOW = (240, 220, 50)
ORANGE = (240, 150, 40)
PURPLE = (160, 60, 200)
CYAN = (50, 220, 220)
PINK = (240, 100, 180)
GOLD = (255, 215, 0)
NEON_PINK = (255, 20, 147)
NEON_BLUE = (0, 255, 255)
NEON_GREEN = (57, 255, 20)
ICE_BLUE = (180, 230, 255)
FIRE_ORANGE = (255, 100, 0)
SPACE_PURPLE = (80, 0, 120)

# ---------------------------------------------------------------------------
# Difficulty presets
# ---------------------------------------------------------------------------
DIFFICULTY = {
    "Easy": {
        "speed": 8.0,
        "speed_increase": 0.15,
        "enemy_speed": 0.6,
        "lives": 5,
        "food_spawn_rate": 1.2,
        "obstacle_density": 0.3,
    },
    "Medium": {
        "speed": 11.0,
        "speed_increase": 0.25,
        "enemy_speed": 1.0,
        "lives": 3,
        "food_spawn_rate": 1.0,
        "obstacle_density": 0.6,
    },
    "Hard": {
        "speed": 14.0,
        "speed_increase": 0.4,
        "enemy_speed": 1.4,
        "lives": 2,
        "food_spawn_rate": 0.8,
        "obstacle_density": 1.0,
    },
}

# ---------------------------------------------------------------------------
# Maps
# ---------------------------------------------------------------------------
MAPS = {
    "Forest": {
        "bg_color": (20, 60, 30),
        "grid_color": (30, 80, 40),
        "wall_color": (60, 40, 20),
        "weather": "rain",
        "music": "forest",
    },
    "Snow": {
        "bg_color": (30, 50, 80),
        "grid_color": (50, 70, 100),
        "wall_color": (180, 200, 220),
        "weather": "snow",
        "music": "snow",
    },
    "Desert": {
        "bg_color": (80, 60, 30),
        "grid_color": (100, 80, 40),
        "wall_color": (140, 100, 50),
        "weather": "none",
        "music": "desert",
    },
    "Space": {
        "bg_color": (10, 5, 30),
        "grid_color": (30, 15, 60),
        "wall_color": (80, 40, 120),
        "weather": "stars",
        "music": "space",
    },
    "Fire": {
        "bg_color": (50, 15, 5),
        "grid_color": (80, 25, 10),
        "wall_color": (180, 60, 20),
        "weather": "none",
        "music": "fire",
    },
    "City": {
        "bg_color": (25, 25, 35),
        "grid_color": (40, 40, 55),
        "wall_color": (70, 70, 90),
        "weather": "fog",
        "music": "city",
    },
}

# ---------------------------------------------------------------------------
# Snake skins
# ---------------------------------------------------------------------------
SKINS = {
    "Classic": {
        "head": GREEN,
        "body": DARK_GREEN,
        "price": 0,
        "unlocked": True,
    },
    "Fire": {
        "head": FIRE_ORANGE,
        "body": RED,
        "price": 150,
        "unlocked": False,
    },
    "Ice": {
        "head": ICE_BLUE,
        "body": CYAN,
        "price": 150,
        "unlocked": False,
    },
    "Neon": {
        "head": NEON_PINK,
        "body": NEON_BLUE,
        "price": 250,
        "unlocked": False,
    },
    "Golden": {
        "head": GOLD,
        "body": YELLOW,
        "price": 400,
        "unlocked": False,
    },
    "Space": {
        "head": SPACE_PURPLE,
        "body": PURPLE,
        "price": 300,
        "unlocked": False,
    },
}

# ---------------------------------------------------------------------------
# Shop items
# ---------------------------------------------------------------------------
SHOP_ITEMS = {
    "extra_life": {
        "name": "Extra Life",
        "name_fa": "جان اضافی",
        "price": 100,
        "description": "Adds one extra life",
        "type": "consumable",
    },
    "slow_enemy": {
        "name": "Slow Enemies",
        "name_fa": "کند کردن دشمنان",
        "price": 80,
        "description": "Slows all enemies for 30 seconds",
        "type": "consumable",
    },
    "coin_magnet": {
        "name": "Coin Magnet",
        "name_fa": "آهنربای سکه",
        "price": 120,
        "description": "Attracts coins for 20 seconds",
        "type": "consumable",
    },
    "shield": {
        "name": "Shield",
        "name_fa": "سپر",
        "price": 150,
        "description": "One-hit protection",
        "type": "consumable",
    },
    "speed_boost": {
        "name": "Speed Boost",
        "name_fa": "افزایش سرعت",
        "price": 60,
        "description": "Temporary speed increase",
        "type": "consumable",
    },
    "double_score": {
        "name": "Double Score",
        "name_fa": "امتیاز دوبرابر",
        "price": 200,
        "description": "Double points for 25 seconds",
        "type": "consumable",
    },
}

# ---------------------------------------------------------------------------
# Food types
# ---------------------------------------------------------------------------
FOOD_TYPES = {
    "normal": {"color": RED, "score": 10, "effect": None, "lifetime": None, "weight": 50},
    "golden": {"color": GOLD, "score": 50, "effect": None, "lifetime": 8.0, "weight": 8},
    "speed": {"color": CYAN, "score": 15, "effect": "speed_up", "lifetime": 6.0, "weight": 10},
    "slow": {"color": BLUE, "score": 15, "effect": "slow_down", "lifetime": 6.0, "weight": 10},
    "double": {"color": PURPLE, "score": 20, "effect": "double_score", "lifetime": 7.0, "weight": 7},
    "poison": {"color": (100, 0, 100), "score": -20, "effect": "poison", "lifetime": 5.0, "weight": 12},
    "rare": {"color": NEON_PINK, "score": 100, "effect": "rare", "lifetime": 4.0, "weight": 3},
    "coin": {"color": YELLOW, "score": 5, "effect": "coin", "lifetime": None, "weight": 20},
}

# ---------------------------------------------------------------------------
# Languages
# ---------------------------------------------------------------------------
TEXTS = {
    "en": {
        "play": "Play",
        "continue": "Continue",
        "settings": "Settings",
        "shop": "Shop",
        "achievements": "Achievements",
        "high_scores": "High Scores",
        "select_map": "Select Map",
        "difficulty": "Difficulty",
        "quit": "Quit",
        "pause": "PAUSED",
        "game_over": "GAME OVER",
        "victory": "VICTORY!",
        "score": "Score",
        "coins": "Coins",
        "lives": "Lives",
        "level": "Level",
        "time": "Time",
        "record": "Record",
        "fps": "FPS",
        "resume": "Resume",
        "restart": "Restart",
        "back": "Back",
        "music": "Music",
        "sfx": "SFX",
        "fullscreen": "Fullscreen",
        "language": "Language",
        "controls": "Controls",
        "volume": "Volume",
        "buy": "Buy",
        "owned": "Owned",
        "equip": "Equip",
        "equipped": "Equipped",
        "inventory": "Inventory",
        "use": "Use",
        "daily": "Daily Missions",
        "weekly": "Weekly Missions",
        "rank": "Rank",
        "xp": "XP",
    },
    "fa": {
        "play": "شروع بازی",
        "continue": "ادامه",
        "settings": "تنظیمات",
        "shop": "فروشگاه",
        "achievements": "دستاوردها",
        "high_scores": "بهترین امتیازها",
        "select_map": "انتخاب نقشه",
        "difficulty": "درجه سختی",
        "quit": "خروج",
        "pause": "توقف",
        "game_over": "بازی تمام شد",
        "victory": "پیروزی!",
        "score": "امتیاز",
        "coins": "سکه",
        "lives": "جان",
        "level": "مرحله",
        "time": "زمان",
        "record": "رکورد",
        "fps": "FPS",
        "resume": "ادامه",
        "restart": "شروع مجدد",
        "back": "بازگشت",
        "music": "موسیقی",
        "sfx": "افکت",
        "fullscreen": "تمام صفحه",
        "language": "زبان",
        "controls": "کنترل‌ها",
        "volume": "صدا",
        "buy": "خرید",
        "owned": "خریداری شده",
        "equip": "انتخاب",
        "equipped": "انتخاب شده",
        "inventory": "موجودی",
        "use": "استفاده",
        "daily": "مأموریت روزانه",
        "weekly": "مأموریت هفتگی",
        "rank": "رتبه",
        "xp": "تجربه",
    },
}


@dataclass
class GameSettings:
    """Persistent game settings."""

    width: int = DEFAULT_WIDTH
    height: int = DEFAULT_HEIGHT
    fullscreen: bool = False
    music_volume: float = 0.5
    sfx_volume: float = 0.7
    music_enabled: bool = True
    sfx_enabled: bool = True
    language: str = "en"
    difficulty: str = "Medium"
    current_map: str = "Forest"
    current_skin: str = "Classic"
    target_fps: int = 60
    show_fps: bool = True
    graphics_quality: str = "High"  # Low / Medium / High
    unlocked_skins: List[str] = field(default_factory=lambda: ["Classic"])
    inventory: Dict[str, int] = field(default_factory=dict)
    coins: int = 0
    total_score: int = 0
    games_played: int = 0
    player_level: int = 1
    player_xp: int = 0
    rank: str = "Novice"

    def save(self) -> None:
        """Save settings to JSON file."""
        os.makedirs(DATA_DIR, exist_ok=True)
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
        except OSError as e:
            print(f"[Settings] Failed to save: {e}")

    @classmethod
    def load(cls) -> "GameSettings":
        """Load settings from JSON or return defaults."""
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # Filter only known fields
                valid = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
                return cls(**valid)
            except (OSError, json.JSONDecodeError, TypeError) as e:
                print(f"[Settings] Load failed, using defaults: {e}")
        return cls()

    def t(self, key: str) -> str:
        """Translate a key according to current language (with Persian shaping)."""
        text = TEXTS.get(self.language, TEXTS["en"]).get(key, key)
        if self.language == "fa":
            return shape_persian(text)
        return text


def shape_persian(text: str) -> str:
    """Reshape and reorder Persian/Arabic text for correct display in pygame."""
    if not text:
        return text
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text


def ensure_data_dir() -> None:
    """Create data directory if missing."""
    os.makedirs(DATA_DIR, exist_ok=True)


# Global settings instance
settings = GameSettings.load()
