"""
sounds.py - Audio manager with graceful fallback when files are missing.
"""

from __future__ import annotations

import os
from typing import Dict, Optional

import pygame

from settings import SOUNDS_DIR, settings


class SoundManager:
    """Manages music and sound effects. Never crashes if assets are missing."""

    def __init__(self) -> None:
        self.music_playing: bool = False
        self.sounds: Dict[str, Optional[pygame.mixer.Sound]] = {}
        self._initialized = False
        self._init_mixer()
        self._load_sounds()

    def _init_mixer(self) -> None:
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
            self._initialized = True
        except pygame.error as e:
            print(f"[Sound] Mixer init failed: {e}")
            self._initialized = False

    def _load_sounds(self) -> None:
        """Load sound effects if files exist, otherwise stay silent."""
        sound_files = {
            "eat": "eat.wav",
            "coin": "coin.wav",
            "buy": "buy.wav",
            "win": "win.wav",
            "lose": "lose.wav",
            "click": "click.wav",
            "pause": "pause.wav",
            "explosion": "explosion.wav",
            "powerup": "powerup.wav",
            "hurt": "hurt.wav",
            "levelup": "levelup.wav",
            "achievement": "achievement.wav",
        }
        for name, filename in sound_files.items():
            path = os.path.join(SOUNDS_DIR, filename)
            if os.path.isfile(path):
                try:
                    self.sounds[name] = pygame.mixer.Sound(path)
                except pygame.error:
                    self.sounds[name] = None
            else:
                self.sounds[name] = None

    def play_sfx(self, name: str, volume: Optional[float] = None) -> None:
        """Play a sound effect if available and enabled."""
        if not self._initialized or not settings.sfx_enabled:
            return
        snd = self.sounds.get(name)
        if snd is not None:
            vol = volume if volume is not None else settings.sfx_volume
            snd.set_volume(max(0.0, min(1.0, vol)))
            try:
                snd.play()
            except pygame.error:
                pass

    def play_music(self, map_name: str = "Forest") -> None:
        """Play background music for the given map (fallback to any available)."""
        if not self._initialized or not settings.music_enabled:
            return
        candidates = [
            f"{map_name.lower()}.ogg",
            f"{map_name.lower()}.mp3",
            f"{map_name.lower()}.wav",
            "menu.wav",
            "bgm.ogg",
            "bgm.mp3",
            "bgm.wav",
            "music.ogg",
            "music.mp3",
            "music.wav",
        ]
        for name in candidates:
            path = os.path.join(SOUNDS_DIR, name)
            if os.path.isfile(path):
                try:
                    pygame.mixer.music.load(path)
                    pygame.mixer.music.set_volume(settings.music_volume)
                    pygame.mixer.music.play(-1)
                    self.music_playing = True
                    return
                except pygame.error:
                    continue
        self.music_playing = False

    def stop_music(self) -> None:
        if self._initialized:
            try:
                pygame.mixer.music.stop()
            except pygame.error:
                pass
        self.music_playing = False

    def set_music_volume(self, vol: float) -> None:
        settings.music_volume = max(0.0, min(1.0, vol))
        if self._initialized:
            try:
                pygame.mixer.music.set_volume(settings.music_volume)
            except pygame.error:
                pass

    def set_sfx_volume(self, vol: float) -> None:
        settings.sfx_volume = max(0.0, min(1.0, vol))

    def toggle_music(self) -> None:
        settings.music_enabled = not settings.music_enabled
        if settings.music_enabled:
            self.play_music(settings.current_map)
        else:
            self.stop_music()
        settings.save()

    def toggle_sfx(self) -> None:
        settings.sfx_enabled = not settings.sfx_enabled
        settings.save()


# Global instance
sound_manager = SoundManager()
