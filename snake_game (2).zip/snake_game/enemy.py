"""
enemy.py - Moving enemies with simple AI (chaser, wanderer, shooter).
"""

from __future__ import annotations

import random
import math
from typing import List, Tuple, Optional, Deque
from collections import deque

import pygame

from settings import CELL_SIZE, GRID_WIDTH, GRID_HEIGHT, RED, ORANGE, PURPLE, CYAN, settings


class Enemy:
    """Base enemy that moves on the grid."""

    def __init__(
        self,
        pos: Tuple[int, int],
        enemy_type: str = "wanderer",
        speed: float = 4.0,
    ) -> None:
        self.pos = pos
        self.enemy_type = enemy_type
        self.speed = speed  # cells per second
        self.move_timer = 0.0
        self.direction = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        self.alive = True
        self.color = RED
        self.pulse = 0.0
        if enemy_type == "chaser":
            self.color = ORANGE
            self.speed *= 1.1
        elif enemy_type == "shooter":
            self.color = PURPLE
            self.speed *= 0.7
            self.shoot_timer = 0.0
        elif enemy_type == "fast":
            self.color = CYAN
            self.speed *= 1.6

    def update(
        self,
        dt: float,
        snake_head: Tuple[int, int],
        obstacles: set,
        snake_body: set,
    ) -> Optional[Tuple[int, int]]:
        """
        Update enemy. Returns projectile position if shooter fires.
        """
        if not self.alive:
            return None
        self.pulse += dt * 5
        self.move_timer += dt * self.speed

        projectile = None
        if self.enemy_type == "shooter":
            self.shoot_timer = getattr(self, "shoot_timer", 0.0) + dt
            if self.shoot_timer >= 2.5:
                self.shoot_timer = 0.0
                # Fire toward snake
                dx = snake_head[0] - self.pos[0]
                dy = snake_head[1] - self.pos[1]
                if abs(dx) > abs(dy):
                    projectile = (1 if dx > 0 else -1, 0)
                else:
                    projectile = (0, 1 if dy > 0 else -1)

        while self.move_timer >= 1.0:
            self.move_timer -= 1.0
            self._choose_direction(snake_head, obstacles, snake_body)
            new_pos = (self.pos[0] + self.direction[0], self.pos[1] + self.direction[1])
            if (
                0 <= new_pos[0] < GRID_WIDTH
                and 0 <= new_pos[1] < GRID_HEIGHT
                and new_pos not in obstacles
            ):
                self.pos = new_pos
            else:
                # Bounce / random new dir
                self.direction = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])

        return projectile

    def _choose_direction(
        self,
        snake_head: Tuple[int, int],
        obstacles: set,
        snake_body: set,
    ) -> None:
        if self.enemy_type == "chaser":
            # Move toward snake
            dx = snake_head[0] - self.pos[0]
            dy = snake_head[1] - self.pos[1]
            options = []
            if dx != 0:
                options.append((1 if dx > 0 else -1, 0))
            if dy != 0:
                options.append((0, 1 if dy > 0 else -1))
            random.shuffle(options)
            for d in options:
                np = (self.pos[0] + d[0], self.pos[1] + d[1])
                if (
                    0 <= np[0] < GRID_WIDTH
                    and 0 <= np[1] < GRID_HEIGHT
                    and np not in obstacles
                ):
                    self.direction = d
                    return
        elif self.enemy_type == "wanderer" or self.enemy_type == "fast":
            if random.random() < 0.15:
                self.direction = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        # shooter keeps current direction mostly

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        if not self.alive:
            return
        px = int(self.pos[0] * CELL_SIZE + offset[0] + CELL_SIZE // 2)
        py = int(self.pos[1] * CELL_SIZE + offset[1] + CELL_SIZE // 2)
        r = CELL_SIZE // 2 - 2
        scale = 1.0 + 0.1 * math.sin(self.pulse)
        rr = int(r * scale)
        pygame.draw.circle(surface, self.color, (px, py), rr)
        # Inner core
        pygame.draw.circle(surface, (255, 255, 255), (px, py), max(2, rr // 3))
        # Type indicator
        if self.enemy_type == "shooter":
            pygame.draw.rect(
                surface,
                (200, 100, 255),
                (px - 2, py - rr - 4, 4, 4),
            )


class Projectile:
    """Simple projectile shot by shooter enemies."""

    def __init__(self, pos: Tuple[int, int], direction: Tuple[int, int]) -> None:
        self.pos = list(pos)
        self.direction = direction
        self.speed = 10.0
        self.timer = 0.0
        self.alive = True

    def update(self, dt: float) -> None:
        self.timer += dt * self.speed
        while self.timer >= 1.0:
            self.timer -= 1.0
            self.pos[0] += self.direction[0]
            self.pos[1] += self.direction[1]
            if not (0 <= self.pos[0] < GRID_WIDTH and 0 <= self.pos[1] < GRID_HEIGHT):
                self.alive = False

    def get_pos(self) -> Tuple[int, int]:
        return (int(self.pos[0]), int(self.pos[1]))

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        if not self.alive:
            return
        px = int(self.pos[0] * CELL_SIZE + offset[0] + CELL_SIZE // 2)
        py = int(self.pos[1] * CELL_SIZE + offset[1] + CELL_SIZE // 2)
        pygame.draw.circle(surface, (255, 100, 255), (px, py), 5)


class EnemyManager:
    """Manages all enemies and projectiles."""

    def __init__(self) -> None:
        self.enemies: List[Enemy] = []
        self.projectiles: List[Projectile] = []
        self.spawn_timer = 0.0

    def clear(self) -> None:
        self.enemies.clear()
        self.projectiles.clear()
        self.spawn_timer = 0.0

    def spawn(self, occupied: set, level: int = 1) -> None:
        free = [
            (x, y)
            for x in range(GRID_WIDTH)
            for y in range(GRID_HEIGHT)
            if (x, y) not in occupied
        ]
        if not free:
            return
        # Prefer far from center
        free.sort(key=lambda p: abs(p[0] - GRID_WIDTH // 2) + abs(p[1] - GRID_HEIGHT // 2), reverse=True)
        pos = free[0]
        types = ["wanderer", "chaser", "fast"]
        if level >= 3:
            types.append("shooter")
        etype = random.choice(types)
        speed = 3.0 + level * 0.3
        self.enemies.append(Enemy(pos, etype, speed))

    def update(
        self,
        dt: float,
        snake_head: Tuple[int, int],
        obstacles: set,
        snake_body: set,
        level: int,
        enemy_speed_mult: float = 1.0,
    ) -> None:
        for e in self.enemies:
            e.speed = e.speed  # base kept
            proj_dir = e.update(dt * enemy_speed_mult, snake_head, obstacles, snake_body)
            if proj_dir:
                self.projectiles.append(Projectile(e.pos, proj_dir))

        for p in self.projectiles:
            p.update(dt)
        self.projectiles = [p for p in self.projectiles if p.alive]

        # Spawn more with level
        max_enemies = min(2 + level // 2, 8)
        self.spawn_timer += dt
        if self.spawn_timer > 8.0 and len(self.enemies) < max_enemies:
            self.spawn_timer = 0.0
            occupied = obstacles | snake_body | {e.pos for e in self.enemies}
            self.spawn(occupied, level)

    def check_collision(self, head: Tuple[int, int]) -> bool:
        """Return True if snake head collides with enemy or projectile."""
        for e in self.enemies:
            if e.alive and e.pos == head:
                return True
        for p in self.projectiles:
            if p.alive and p.get_pos() == head:
                p.alive = False
                return True
        return False

    def get_occupied(self) -> set:
        return {e.pos for e in self.enemies if e.alive}

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        for e in self.enemies:
            e.draw(surface, offset)
        for p in self.projectiles:
            p.draw(surface, offset)
