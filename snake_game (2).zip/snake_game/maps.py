"""
maps.py - Map definitions, static & moving obstacles.
"""

from __future__ import annotations

import random
from typing import List, Tuple, Set

import pygame

from settings import (
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    MAPS,
    settings,
)


class Obstacle:
    """Static or moving obstacle."""

    def __init__(
        self,
        pos: Tuple[int, int],
        moving: bool = False,
        path: List[Tuple[int, int]] = None,
    ) -> None:
        self.pos = pos
        self.moving = moving
        self.path = path or []
        self.path_index = 0
        self.move_timer = 0.0
        self.speed = 2.0
        self.color = (100, 80, 60)

    def update(self, dt: float) -> None:
        if not self.moving or not self.path:
            return
        self.move_timer += dt * self.speed
        if self.move_timer >= 1.0:
            self.move_timer = 0.0
            self.path_index = (self.path_index + 1) % len(self.path)
            self.pos = self.path[self.path_index]

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0), wall_color=None) -> None:
        color = wall_color or self.color
        px = int(self.pos[0] * CELL_SIZE + offset[0])
        py = int(self.pos[1] * CELL_SIZE + offset[1])
        rect = pygame.Rect(px + 1, py + 1, CELL_SIZE - 2, CELL_SIZE - 2)
        pygame.draw.rect(surface, color, rect, border_radius=3)
        # Inner detail
        pygame.draw.rect(
            surface,
            tuple(max(0, c - 30) for c in color),
            rect.inflate(-6, -6),
            border_radius=2,
        )


class GameMap:
    """Represents a playable map with obstacles and theme."""

    def __init__(self, name: str = "Forest") -> None:
        self.name = name if name in MAPS else "Forest"
        self.data = MAPS[self.name]
        self.obstacles: List[Obstacle] = []
        self.bg_color = self.data["bg_color"]
        self.grid_color = self.data["grid_color"]
        self.wall_color = self.data["wall_color"]
        self.weather = self.data["weather"]
        self._generate_obstacles()

    def _generate_obstacles(self) -> None:
        self.obstacles.clear()
        density = 0.4
        if settings.difficulty == "Easy":
            density = 0.25
        elif settings.difficulty == "Hard":
            density = 0.7

        # Border walls (visual only - collision handled by bounds)
        # Internal static obstacles
        count = int(GRID_WIDTH * GRID_HEIGHT * 0.04 * density)
        occupied = set()
        center = (GRID_WIDTH // 2, GRID_HEIGHT // 2)
        for _ in range(count):
            x = random.randint(2, GRID_WIDTH - 3)
            y = random.randint(2, GRID_HEIGHT - 3)
            if abs(x - center[0]) < 4 and abs(y - center[1]) < 4:
                continue
            if (x, y) not in occupied:
                occupied.add((x, y))
                self.obstacles.append(Obstacle((x, y), moving=False))

        # A few moving obstacles
        moving_count = max(1, int(2 * density))
        for _ in range(moving_count):
            x = random.randint(3, GRID_WIDTH - 4)
            y = random.randint(3, GRID_HEIGHT - 4)
            if (x, y) in occupied:
                continue
            # Horizontal path
            path = [(x + i, y) for i in range(-3, 4) if 0 <= x + i < GRID_WIDTH]
            if len(path) >= 3:
                self.obstacles.append(Obstacle(path[0], moving=True, path=path))
                for p in path:
                    occupied.add(p)

    def get_occupied(self) -> Set[Tuple[int, int]]:
        return {o.pos for o in self.obstacles}

    def update(self, dt: float) -> None:
        for o in self.obstacles:
            o.update(dt)

    def draw_background(self, surface: pygame.Surface) -> None:
        surface.fill(self.bg_color)
        # Subtle grid
        if settings.graphics_quality != "Low":
            for x in range(0, GRID_WIDTH):
                for y in range(0, GRID_HEIGHT):
                    if (x + y) % 2 == 0:
                        rect = pygame.Rect(
                            x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE
                        )
                        s = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
                        s.fill((*self.grid_color, 30))
                        surface.blit(s, rect.topleft)

    def draw_obstacles(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        for o in self.obstacles:
            o.draw(surface, offset, self.wall_color)

    def is_blocked(self, pos: Tuple[int, int]) -> bool:
        return pos in self.get_occupied()
