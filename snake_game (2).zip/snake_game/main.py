"""
main.py - Entry point for Desert Breeze: The Serpent.
Professional modular Snake game with Pygame.
"""

from __future__ import annotations

import sys
import os
import traceback

import pygame

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from settings import settings, ensure_data_dir, DEFAULT_WIDTH, DEFAULT_HEIGHT
from sounds import sound_manager
from save import load_game_state
from menu import (
    MainMenu,
    SettingsMenu,
    HighScoresMenu,
    AchievementsMenu,
    MapSelectMenu,
    DifficultyMenu,
)
from shop import Shop
from game import Game
from ui import Notification


class App:
    """Application state machine."""

    def __init__(self) -> None:
        ensure_data_dir()
        pygame.init()
        pygame.joystick.init()

        flags = pygame.FULLSCREEN if settings.fullscreen else 0
        self.screen = pygame.display.set_mode(
            (settings.width, settings.height), flags, vsync=1
        )
        pygame.display.set_caption("Desert Breeze: The Serpent")
        self.clock = pygame.time.Clock()
        self.running = True

        # Fonts (fallback to default if custom fonts missing)
        self.fonts = self._load_fonts()

        # Joysticks
        self.joysticks = []
        for i in range(pygame.joystick.get_count()):
            j = pygame.joystick.Joystick(i)
            j.init()
            self.joysticks.append(j)

        self.state = "menu"  # menu | game | settings | shop | achievements | highscores | map | difficulty
        self.game: Game | None = None
        self.fps = 60

        self.menu = MainMenu(self.fonts, {
            "play": self.start_game,
            "continue": self.continue_game,
            "settings": lambda: self.set_state("settings"),
            "shop": lambda: self.set_state("shop"),
            "achievements": lambda: self.set_state("achievements"),
            "high_scores": lambda: self.set_state("highscores"),
            "select_map": lambda: self.set_state("map"),
            "difficulty": lambda: self.set_state("difficulty"),
            "quit": self.quit,
        })
        self.settings_menu = SettingsMenu(self.fonts, lambda: self.set_state("menu"))
        self.shop_menu = Shop(self.fonts, lambda: self.set_state("menu"))
        self.achievements_menu = AchievementsMenu(self.fonts, lambda: self.set_state("menu"))
        self.highscores_menu = HighScoresMenu(self.fonts, lambda: self.set_state("menu"))
        self.map_menu = MapSelectMenu(self.fonts, lambda: self.set_state("menu"))
        self.diff_menu = DifficultyMenu(self.fonts, lambda: self.set_state("menu"))

        sound_manager.play_music("menu")

    def _load_fonts(self) -> dict:
        """Load Vazirmatn for Persian support, fallback to system fonts."""
        from settings import FONTS_DIR
        fonts = {}
        regular = os.path.join(FONTS_DIR, "Vazirmatn-Regular.ttf")
        bold = os.path.join(FONTS_DIR, "Vazirmatn-Bold.ttf")
        try:
            if os.path.isfile(bold) and os.path.isfile(regular):
                fonts["title"] = pygame.font.Font(bold, 64)
                fonts["large"] = pygame.font.Font(bold, 40)
                fonts["medium"] = pygame.font.Font(regular, 26)
                fonts["small"] = pygame.font.Font(regular, 20)
                fonts["tiny"] = pygame.font.Font(regular, 16)
            else:
                raise FileNotFoundError("Vazirmatn not found")
        except Exception:
            try:
                fonts["title"] = pygame.font.SysFont("segoeui", 72, bold=True)
                fonts["large"] = pygame.font.SysFont("segoeui", 42, bold=True)
                fonts["medium"] = pygame.font.SysFont("segoeui", 28)
                fonts["small"] = pygame.font.SysFont("segoeui", 20)
                fonts["tiny"] = pygame.font.SysFont("segoeui", 16)
            except Exception:
                fonts["title"] = pygame.font.Font(None, 72)
                fonts["large"] = pygame.font.Font(None, 42)
                fonts["medium"] = pygame.font.Font(None, 28)
                fonts["small"] = pygame.font.Font(None, 20)
                fonts["tiny"] = pygame.font.Font(None, 16)
        return fonts

    def set_state(self, state: str) -> None:
        self.state = state
        if state == "menu":
            self.menu.refresh()
            sound_manager.play_music("menu")
        elif state == "settings":
            self.settings_menu._build()
        elif state == "shop":
            self.shop_menu._build_ui()
        elif state == "map":
            self.map_menu._build()
        elif state == "difficulty":
            self.diff_menu._build()
        elif state == "highscores":
            self.highscores_menu.records = __import__("save").load_records()

    def start_game(self) -> None:
        self.game = Game(self.fonts, lambda: self.set_state("menu"))
        self.state = "game"

    def continue_game(self) -> None:
        state = load_game_state()
        if state:
            self.game = Game(self.fonts, lambda: self.set_state("menu"), continue_state=state)
            self.state = "game"
        else:
            self.start_game()

    def quit(self) -> None:
        settings.save()
        self.running = False

    def toggle_fullscreen(self) -> None:
        settings.fullscreen = not settings.fullscreen
        settings.save()
        flags = pygame.FULLSCREEN if settings.fullscreen else 0
        self.screen = pygame.display.set_mode(
            (settings.width, settings.height), flags, vsync=1
        )

    def run(self) -> None:
        mouse_down = False
        while self.running:
            dt = self.clock.tick(settings.target_fps) / 1000.0
            dt = min(dt, 0.05)  # clamp large spikes
            self.fps = self.clock.get_fps()

            mouse_pos = pygame.mouse.get_pos()
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    self.quit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11:
                        self.toggle_fullscreen()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mouse_down = True
                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        mouse_down = False

                if self.state == "game" and self.game:
                    self.game.handle_event(event)

            # Update
            try:
                if self.state == "menu":
                    self.menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "settings":
                    self.settings_menu.update(dt, mouse_pos, mouse_down)
                    # Detect fullscreen toggle side-effect
                    if settings.fullscreen != (bool(self.screen.get_flags() & pygame.FULLSCREEN)):
                        self.toggle_fullscreen()
                elif self.state == "shop":
                    self.shop_menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "achievements":
                    self.achievements_menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "highscores":
                    self.highscores_menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "map":
                    self.map_menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "difficulty":
                    self.diff_menu.update(dt, mouse_pos, mouse_down)
                elif self.state == "game" and self.game:
                    self.game.update(dt, mouse_pos, mouse_down)
            except Exception as e:
                print(f"[Update Error] {e}")
                traceback.print_exc()

            # Draw
            try:
                if self.state == "menu":
                    self.menu.draw(self.screen)
                elif self.state == "settings":
                    self.settings_menu.draw(self.screen)
                elif self.state == "shop":
                    self.shop_menu.draw(self.screen)
                elif self.state == "achievements":
                    self.achievements_menu.draw(self.screen)
                elif self.state == "highscores":
                    self.highscores_menu.draw(self.screen)
                elif self.state == "map":
                    self.map_menu.draw(self.screen)
                elif self.state == "difficulty":
                    self.diff_menu.draw(self.screen)
                elif self.state == "game" and self.game:
                    self.game.draw(self.screen)

                # FPS counter
                if settings.show_fps:
                    fps_surf = self.fonts["tiny"].render(f"FPS: {self.fps:.0f}", True, (180, 180, 180))
                    self.screen.blit(fps_surf, (settings.width - 80, settings.height - 24))

                pygame.display.flip()
            except Exception as e:
                print(f"[Draw Error] {e}")
                traceback.print_exc()

        pygame.quit()
        sys.exit(0)


def main() -> None:
    try:
        app = App()
        app.run()
    except Exception as e:
        print(f"Fatal error: {e}")
        traceback.print_exc()
        pygame.quit()
        sys.exit(1)


if __name__ == "__main__":
    main()
