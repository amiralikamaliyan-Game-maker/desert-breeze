"""
snake.py - Snake entity with smooth movement, skins and lives.
"""

from __future__ import annotations

from typing import List, Tuple, Optional, Deque
from collections import deque
import math

import pygame

from settings import (
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    SKINS,
    settings,
    GREEN,
    DARK_GREEN,
    WHITE,
    BLACK,
)


class Snake:
    """Player-controlled snake with smooth interpolation."""

    def __init__(self, start_pos: Tuple[int, int] = (GRID_WIDTH // 2, GRID_HEIGHT // 2)) -> None:
        self.body: Deque[Tuple[int, int]] = deque([start_pos])
        self.direction = (1, 0)
        self.next_direction = (1, 0)
        self.grow_pending = 0
        self.alive = True
        self.lives = 3
        self.invincible_timer = 0.0
        self.shield_active = False
        self.move_timer = 0.0
        self.base_speed = 10.0  # cells per second
        self.speed_multiplier = 1.0
        self.skin = settings.current_skin
        # Smooth visual positions
        self.visual_positions: List[Tuple[float, float]] = [(float(start_pos[0]), float(start_pos[1]))]
        self.prev_body: List[Tuple[int, int]] = [start_pos]

    def reset(self, start_pos: Tuple[int, int] = (GRID_WIDTH // 2, GRID_HEIGHT // 2)) -> None:
        self.body = deque([start_pos])
        self.direction = (1, 0)
        self.next_direction = (1, 0)
        self.grow_pending = 0
        self.alive = True
        self.invincible_timer = 1.5
        self.move_timer = 0.0
        self.speed_multiplier = 1.0
        self.visual_positions = [(float(start_pos[0]), float(start_pos[1]))]
        self.prev_body = [start_pos]

    def set_direction(self, dx: int, dy: int) -> None:
        """Set next direction (prevents 180° turn)."""
        if (dx, dy) == (-self.direction[0], -self.direction[1]):
            return
        if (dx, dy) != (0, 0):
            self.next_direction = (dx, dy)

    def update(self, dt: float) -> bool:
        """
        Update snake. Returns True if a grid move occurred.
        Uses delta-time based movement for smooth speed.
        """
        if not self.alive:
            return False

        if self.invincible_timer > 0:
            self.invincible_timer -= dt

        speed = self.base_speed * self.speed_multiplier
        self.move_timer += dt * speed

        moved = False
        while self.move_timer >= 1.0:
            self.move_timer -= 1.0
            self._do_move()
            moved = True

        # Interpolate visual positions
        t = self.move_timer  # 0..1 progress to next cell
        self._update_visuals(t)
        return moved

    def _do_move(self) -> None:
        self.direction = self.next_direction
        head = self.body[0]
        new_head = (head[0] + self.direction[0], head[1] + self.direction[1])

        # Wall collision
        if not (0 <= new_head[0] < GRID_WIDTH and 0 <= new_head[1] < GRID_HEIGHT):
            self._hit()
            return

        # Self collision
        if new_head in list(self.body)[1:]:
            self._hit()
            return

        self.prev_body = list(self.body)
        self.body.appendleft(new_head)

        if self.grow_pending > 0:
            self.grow_pending -= 1
        else:
            self.body.pop()

    def _hit(self) -> None:
        if self.invincible_timer > 0 or self.shield_active:
            self.shield_active = False
            self.invincible_timer = 1.0
            return
        self.lives -= 1
        if self.lives <= 0:
            self.alive = False
        else:
            # Respawn with invincibility
            self.invincible_timer = 2.0
            # Shrink a bit as penalty
            while len(self.body) > 3:
                self.body.pop()

    def _update_visuals(self, t: float) -> None:
        """Smooth body interpolation between grid positions."""
        self.visual_positions = []
        body_list = list(self.body)
        prev = self.prev_body
        for i, pos in enumerate(body_list):
            if i < len(prev):
                px, py = prev[i]
                vx = px + (pos[0] - px) * t
                vy = py + (pos[1] - py) * t
            else:
                vx, vy = float(pos[0]), float(pos[1])
            self.visual_positions.append((vx, vy))

    def grow(self, amount: int = 1) -> None:
        self.grow_pending += amount

    def get_head(self) -> Tuple[int, int]:
        return self.body[0]

    def occupies(self, pos: Tuple[int, int]) -> bool:
        return pos in self.body

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        skin_data = SKINS.get(self.skin, SKINS["Classic"])
        head_color = skin_data["head"]
        body_color = skin_data["body"]

        # Blink when invincible
        if self.invincible_timer > 0 and int(self.invincible_timer * 8) % 2 == 0:
            return

        for i, (vx, vy) in enumerate(self.visual_positions):
            px = int(vx * CELL_SIZE + offset[0])
            py = int(vy * CELL_SIZE + offset[1])
            rect = pygame.Rect(px + 1, py + 1, CELL_SIZE - 2, CELL_SIZE - 2)

            if i == 0:
                # Head
                pygame.draw.rect(surface, head_color, rect, border_radius=6)
                # Eyes
                eye_offset_x = 4 if self.direction[0] >= 0 else CELL_SIZE - 8
                eye_offset_y = 4 if self.direction[1] >= 0 else CELL_SIZE - 8
                if self.direction[0] != 0:
                    pygame.draw.circle(surface, WHITE, (px + eye_offset_x, py + 5), 3)
                    pygame.draw.circle(surface, WHITE, (px + eye_offset_x, py + CELL_SIZE - 6), 3)
                    pygame.draw.circle(surface, BLACK, (px + eye_offset_x + 1, py + 5), 1)
                    pygame.draw.circle(surface, BLACK, (px + eye_offset_x + 1, py + CELL_SIZE - 6), 1)
                else:
                    pygame.draw.circle(surface, WHITE, (px + 5, py + eye_offset_y), 3)
                    pygame.draw.circle(surface, WHITE, (px + CELL_SIZE - 6, py + eye_offset_y), 3)
                    pygame.draw.circle(surface, BLACK, (px + 5, py + eye_offset_y + 1), 1)
                    pygame.draw.circle(surface, BLACK, (px + CELL_SIZE - 6, py + eye_offset_y + 1), 1)
            else:
                # Body segment with slight gradient
                factor = 1.0 - (i / max(1, len(self.visual_positions))) * 0.3
                c = tuple(int(c * factor) for c in body_color)
                pygame.draw.rect(surface, c, rect, border_radius=4)

            # Shield visual
            if self.shield_active and i == 0:
                pygame.draw.rect(surface, (100, 200, 255), rect.inflate(6, 6), width=2, border_radius=8)
