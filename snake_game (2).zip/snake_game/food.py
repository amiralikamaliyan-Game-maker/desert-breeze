"""
food.py - Multiple food types with glow, lifetime and effects.
"""

from __future__ import annotations

import random
import math
from typing import List, Tuple, Optional, Dict, Any

import pygame

from settings import (
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    FOOD_TYPES,
    settings,
)
from effects import draw_glow


class Food:
    """A single food item on the grid."""

    def __init__(self, pos: Tuple[int, int], food_type: str = "normal") -> None:
        self.pos = pos
        self.food_type = food_type
        data = FOOD_TYPES.get(food_type, FOOD_TYPES["normal"])
        self.color = data["color"]
        self.score = data["score"]
        self.effect = data["effect"]
        self.lifetime = data["lifetime"]
        self.timer = self.lifetime if self.lifetime else None
        self.pulse = random.uniform(0, math.pi * 2)
        self.alive = True

    def update(self, dt: float) -> None:
        self.pulse += dt * 4
        if self.timer is not None:
            self.timer -= dt
            if self.timer <= 0:
                self.alive = False

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        if not self.alive:
            return
        px = int(self.pos[0] * CELL_SIZE + offset[0] + CELL_SIZE // 2)
        py = int(self.pos[1] * CELL_SIZE + offset[1] + CELL_SIZE // 2)
        base_r = CELL_SIZE // 2 - 2
        scale = 1.0 + 0.15 * math.sin(self.pulse)
        r = int(base_r * scale)

        # Glow for special foods
        if self.food_type in ("golden", "rare", "double", "speed"):
            draw_glow(surface, (px, py), r + 4, self.color, intensity=2)

        pygame.draw.circle(surface, self.color, (px, py), r)
        # Highlight
        pygame.draw.circle(
            surface,
            tuple(min(255, c + 60) for c in self.color),
            (px - r // 3, py - r // 3),
            max(2, r // 3),
        )

        # Lifetime bar for timed foods
        if self.timer is not None and self.lifetime:
            bar_w = CELL_SIZE - 4
            bar_h = 3
            ratio = max(0.0, self.timer / self.lifetime)
            bx = int(self.pos[0] * CELL_SIZE + offset[0] + 2)
            by = int(self.pos[1] * CELL_SIZE + offset[1] + CELL_SIZE - 5)
            pygame.draw.rect(surface, (40, 40, 40), (bx, by, bar_w, bar_h))
            pygame.draw.rect(surface, self.color, (bx, by, int(bar_w * ratio), bar_h))


class FoodManager:
    """Spawns and manages multiple food items."""

    def __init__(self) -> None:
        self.foods: List[Food] = []
        self.spawn_timer = 0.0
        self.spawn_interval = 1.5

    def clear(self) -> None:
        self.foods.clear()
        self.spawn_timer = 0.0

    def _random_type(self) -> str:
        weights = [(k, v["weight"]) for k, v in FOOD_TYPES.items()]
        total = sum(w for _, w in weights)
        r = random.uniform(0, total)
        acc = 0
        for name, w in weights:
            acc += w
            if r <= acc:
                return name
        return "normal"

    def spawn(self, occupied: set) -> None:
        """Spawn one food at free cell."""
        free = [
            (x, y)
            for x in range(GRID_WIDTH)
            for y in range(GRID_HEIGHT)
            if (x, y) not in occupied
        ]
        if not free:
            return
        pos = random.choice(free)
        ftype = self._random_type()
        self.foods.append(Food(pos, ftype))

    def update(self, dt: float, occupied: set, spawn_rate: float = 1.0) -> None:
        for f in self.foods:
            f.update(dt)
        self.foods = [f for f in self.foods if f.alive]

        self.spawn_timer += dt * spawn_rate
        # Keep at least 1-3 foods
        target = 2 if len(self.foods) < 2 else 0
        if self.spawn_timer >= self.spawn_interval or target:
            self.spawn_timer = 0.0
            if len(self.foods) < 5:
                self.spawn(occupied)

    def check_collision(self, head: Tuple[int, int]) -> Optional[Food]:
        for f in self.foods:
            if f.alive and f.pos == head:
                f.alive = False
                return f
        return None

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        for f in self.foods:
            f.draw(surface, offset)

    def get_occupied(self) -> set:
        return {f.pos for f in self.foods if f.alive}
