"""
shop.py - Shop system for skins and consumable items.
"""

from __future__ import annotations

from typing import Optional, Callable, List, Dict, Any

import pygame

from settings import (
    settings,
    SKINS,
    SHOP_ITEMS,
    GOLD,
    WHITE,
    GRAY,
    GREEN,
    DARK_GRAY,
    CYAN,
)
from sounds import sound_manager
from ui import Button, Panel, Label
from achievements import achievement_manager


class Shop:
    """In-game shop UI and purchase logic."""

    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.buttons: List[Button] = []
        self.message = ""
        self.message_timer = 0.0
        self.tab = "skins"  # skins | items
        self._build_ui()

    def _build_ui(self) -> None:
        self.buttons.clear()
        w, h = settings.width, settings.height
        # Tabs
        self.buttons.append(
            Button(w // 2 - 160, 80, 140, 40, "Skins", lambda: self._set_tab("skins"), self.fonts["medium"])
        )
        self.buttons.append(
            Button(w // 2 + 20, 80, 140, 40, "Items", lambda: self._set_tab("items"), self.fonts["medium"])
        )
        self.buttons.append(
            Button(30, h - 70, 140, 45, settings.t("back"), self.on_back, self.fonts["medium"], color=(80, 50, 50))
        )

    def _set_tab(self, tab: str) -> None:
        self.tab = tab

    def buy_skin(self, name: str) -> None:
        skin = SKINS.get(name)
        if not skin:
            return
        if name in settings.unlocked_skins:
            settings.current_skin = name
            settings.save()
            self.message = f"Equipped {name}"
            self.message_timer = 2.0
            sound_manager.play_sfx("click")
            return
        if settings.coins >= skin["price"]:
            settings.coins -= skin["price"]
            settings.unlocked_skins.append(name)
            settings.current_skin = name
            settings.save()
            self.message = f"Bought {name}!"
            self.message_timer = 2.0
            sound_manager.play_sfx("buy")
            achievement_manager.update_stats(
                unlocked_skins=settings.unlocked_skins,
                items_bought=1,
            )
        else:
            self.message = "Not enough coins!"
            self.message_timer = 2.0

    def buy_item(self, item_id: str) -> None:
        item = SHOP_ITEMS.get(item_id)
        if not item:
            return
        if settings.coins >= item["price"]:
            settings.coins -= item["price"]
            inv = settings.inventory
            inv[item_id] = inv.get(item_id, 0) + 1
            settings.inventory = inv
            settings.save()
            self.message = f"Bought {item['name']}!"
            self.message_timer = 2.0
            sound_manager.play_sfx("buy")
            achievement_manager.update_stats(items_bought=1)
        else:
            self.message = "Not enough coins!"
            self.message_timer = 2.0

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        for b in self.buttons:
            b.update(dt, mouse_pos, mouse_down)
        if self.message_timer > 0:
            self.message_timer -= dt

        # Dynamic buy buttons handled in draw + click regions
        # Simple click detection for list items
        if mouse_down:
            self._handle_item_clicks(mouse_pos)

    def _handle_item_clicks(self, mouse_pos) -> None:
        w, h = settings.width, settings.height
        y = 150
        if self.tab == "skins":
            for name, data in SKINS.items():
                rect = pygame.Rect(w // 2 - 200, y, 400, 50)
                if rect.collidepoint(mouse_pos):
                    self.buy_skin(name)
                    return
                y += 60
        else:
            for iid, data in SHOP_ITEMS.items():
                rect = pygame.Rect(w // 2 - 200, y, 400, 50)
                if rect.collidepoint(mouse_pos):
                    self.buy_item(iid)
                    return
                y += 60

    def draw(self, surface: pygame.Surface) -> None:
        w, h = settings.width, settings.height
        # Background
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("shop"), True, GOLD)
        surface.blit(title, title.get_rect(center=(w // 2, 40)))

        # Coins
        coins_text = self.fonts["medium"].render(f"{settings.t('coins')}: {settings.coins}", True, GOLD)
        surface.blit(coins_text, (w - 200, 30))

        for b in self.buttons:
            b.draw(surface)

        y = 150
        if self.tab == "skins":
            for name, data in SKINS.items():
                rect = pygame.Rect(w // 2 - 200, y, 400, 50)
                owned = name in settings.unlocked_skins
                equipped = settings.current_skin == name
                bg = (40, 60, 40) if equipped else (40, 40, 55)
                pygame.draw.rect(surface, bg, rect, border_radius=8)
                pygame.draw.rect(surface, data["head"], (rect.x + 10, rect.y + 10, 30, 30), border_radius=4)
                label = name
                if equipped:
                    label += " [Equipped]"
                elif owned:
                    label += " [Owned]"
                else:
                    label += f" - {data['price']} coins"
                txt = self.fonts["small"].render(label, True, WHITE)
                surface.blit(txt, (rect.x + 50, rect.y + 15))
                y += 60
        else:
            for iid, data in SHOP_ITEMS.items():
                rect = pygame.Rect(w // 2 - 200, y, 400, 50)
                pygame.draw.rect(surface, (40, 40, 55), rect, border_radius=8)
                count = settings.inventory.get(iid, 0)
                label = f"{data['name']} - {data['price']} coins (x{count})"
                txt = self.fonts["small"].render(label, True, WHITE)
                surface.blit(txt, (rect.x + 15, rect.y + 15))
                y += 60

        if self.message_timer > 0:
            msg = self.fonts["medium"].render(self.message, True, GREEN)
            surface.blit(msg, msg.get_rect(center=(w // 2, h - 100)))
