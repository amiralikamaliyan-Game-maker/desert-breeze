"""
menu.py - Main menu, settings screen, high scores, achievements view, map & difficulty select.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Any

import pygame

from settings import (
    settings,
    MAPS,
    DIFFICULTY,
    GOLD,
    WHITE,
    CYAN,
    GREEN,
    GRAY,
)
from ui import Button, Slider, Panel, Label, MenuAnimator, Notification
from sounds import sound_manager
from save import load_records, load_game_state
from achievements import achievement_manager
from shop import Shop


class MainMenu:
    """Main menu with animated buttons and logo."""

    def __init__(
        self,
        fonts: Dict[str, pygame.font.Font],
        callbacks: Dict[str, Callable],
    ) -> None:
        self.fonts = fonts
        self.callbacks = callbacks
        self.buttons: List[Button] = []
        self.animator = MenuAnimator()
        self.animator.fade_in()
        self.logo_pulse = 0.0
        self._build()

    def _build(self) -> None:
        self.buttons.clear()
        w, h = settings.width, settings.height
        bw, bh = 280, 50
        cx = w // 2 - bw // 2
        start_y = 180
        gap = 58

        labels = [
            ("play", "play"),
            ("continue", "continue"),
            ("settings", "settings"),
            ("shop", "shop"),
            ("achievements", "achievements"),
            ("high_scores", "high_scores"),
            ("select_map", "select_map"),
            ("difficulty", "difficulty"),
            ("quit", "quit"),
        ]
        for i, (key, cb_key) in enumerate(labels):
            text = settings.t(key)
            # Disable continue if no save
            enabled = True
            if key == "continue" and load_game_state() is None:
                enabled = False
            btn = Button(
                cx,
                start_y + i * gap,
                bw,
                bh,
                text,
                self.callbacks.get(cb_key),
                self.fonts["medium"],
                color=(40, 100, 70) if key != "quit" else (120, 40, 40),
                hover_color=(60, 150, 100) if key != "quit" else (160, 60, 60),
            )
            btn.enabled = enabled
            self.buttons.append(btn)

    def refresh(self) -> None:
        self._build()

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        self.animator.update(dt)
        self.logo_pulse += dt * 2
        for b in self.buttons:
            b.update(dt, mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = settings.width, settings.height
        surface.fill((12, 18, 28))

        # Animated background circles
        import math
        for i in range(5):
            r = 80 + i * 40 + int(20 * math.sin(self.logo_pulse + i))
            alpha = 20 + i * 5
            s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (30, 80, 50, alpha), (r, r), r)
            surface.blit(s, (w // 2 - r, 80 - r // 2))

        # Logo
        logo = self.fonts["title"].render("Desert Breeze", True, GOLD)
        logo_rect = logo.get_rect(center=(w // 2, 80))
        surface.blit(logo, logo_rect)
        sub = self.fonts["medium"].render("The Serpent", True, CYAN)
        surface.blit(sub, sub.get_rect(center=(w // 2, 125)))

        for b in self.buttons:
            b.draw(surface)

        # Version / player info
        info = self.fonts["tiny"].render(
            f"Lv.{settings.player_level} {settings.rank} | Coins: {settings.coins}",
            True,
            GRAY,
        )
        surface.blit(info, (20, h - 30))

        self.animator.draw_overlay(surface)


class SettingsMenu:
    """Full settings screen."""

    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.buttons: List[Button] = []
        self.sliders: List[Slider] = []
        self._build()

    def _build(self) -> None:
        self.buttons.clear()
        self.sliders.clear()
        w, h = settings.width, settings.height

        self.sliders.append(
            Slider(w // 2 - 100, 180, 200, settings.music_volume, callback=self._set_music_vol)
        )
        self.sliders.append(
            Slider(w // 2 - 100, 250, 200, settings.sfx_volume, callback=self._set_sfx_vol)
        )

        self.buttons.append(
            Button(w // 2 - 120, 320, 240, 45, f"Music: {'ON' if settings.music_enabled else 'OFF'}",
                   self._toggle_music, self.fonts["medium"])
        )
        self.buttons.append(
            Button(w // 2 - 120, 380, 240, 45, f"SFX: {'ON' if settings.sfx_enabled else 'OFF'}",
                   self._toggle_sfx, self.fonts["medium"])
        )
        self.buttons.append(
            Button(w // 2 - 120, 440, 240, 45, f"Fullscreen: {'ON' if settings.fullscreen else 'OFF'}",
                   self._toggle_fs, self.fonts["medium"])
        )
        self.buttons.append(
            Button(w // 2 - 120, 500, 240, 45, f"Lang: {settings.language.upper()}",
                   self._toggle_lang, self.fonts["medium"])
        )
        self.buttons.append(
            Button(w // 2 - 120, 560, 240, 45, f"Graphics: {settings.graphics_quality}",
                   self._cycle_quality, self.fonts["medium"])
        )
        self.buttons.append(
            Button(30, h - 70, 140, 45, settings.t("back"), self.on_back, self.fonts["medium"], color=(80, 50, 50))
        )

    def _set_music_vol(self, v: float) -> None:
        sound_manager.set_music_volume(v)
        settings.save()

    def _set_sfx_vol(self, v: float) -> None:
        sound_manager.set_sfx_volume(v)
        settings.save()

    def _toggle_music(self) -> None:
        sound_manager.toggle_music()
        self._build()

    def _toggle_sfx(self) -> None:
        sound_manager.toggle_sfx()
        self._build()

    def _toggle_fs(self) -> None:
        settings.fullscreen = not settings.fullscreen
        settings.save()
        # Actual toggle handled by main
        self._build()

    def _toggle_lang(self) -> None:
        settings.language = "fa" if settings.language == "en" else "en"
        settings.save()
        self._build()

    def _cycle_quality(self) -> None:
        order = ["Low", "Medium", "High"]
        idx = order.index(settings.graphics_quality) if settings.graphics_quality in order else 2
        settings.graphics_quality = order[(idx + 1) % 3]
        settings.save()
        self._build()

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        for b in self.buttons:
            b.update(dt, mouse_pos, mouse_down)
        for s in self.sliders:
            s.update(mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = settings.width, settings.height
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("settings"), True, GOLD)
        surface.blit(title, title.get_rect(center=(w // 2, 50)))

        # Labels
        t1 = self.fonts["small"].render(settings.t("music") + f" {int(settings.music_volume*100)}%", True, WHITE)
        surface.blit(t1, (w // 2 - 100, 150))
        t2 = self.fonts["small"].render(settings.t("sfx") + f" {int(settings.sfx_volume*100)}%", True, WHITE)
        surface.blit(t2, (w // 2 - 100, 220))

        for s in self.sliders:
            s.draw(surface)
        for b in self.buttons:
            b.draw(surface)

        # Controls help
        help_lines = [
            "Controls: Arrow Keys / WASD - Move",
            "P - Pause | R - Restart | ESC - Menu",
            "Gamepad supported",
        ]
        for i, line in enumerate(help_lines):
            txt = self.fonts["tiny"].render(line, True, GRAY)
            surface.blit(txt, (w // 2 - 150, h - 140 + i * 22))


class HighScoresMenu:
    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.records = load_records()
        self.back_btn = Button(30, settings.height - 70, 140, 45, settings.t("back"), on_back, fonts["medium"], color=(80, 50, 50))

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        self.back_btn.update(dt, mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = settings.width, settings.height
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("high_scores"), True, GOLD)
        surface.blit(title, title.get_rect(center=(w // 2, 40)))
        if not self.records:
            empty = self.fonts["medium"].render("No records yet", True, GRAY)
            surface.blit(empty, empty.get_rect(center=(w // 2, h // 2)))
        else:
            y = 100
            for i, rec in enumerate(self.records[:15]):
                line = f"{i+1}. {rec.get('name', 'Player')} - {rec.get('score', 0)}  ({rec.get('map', '')} / {rec.get('difficulty', '')})"
                color = GOLD if i == 0 else WHITE
                txt = self.fonts["small"].render(line, True, color)
                surface.blit(txt, (w // 2 - 250, y))
                y += 35
        self.back_btn.draw(surface)


class AchievementsMenu:
    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.back_btn = Button(30, settings.height - 70, 140, 45, settings.t("back"), on_back, fonts["medium"], color=(80, 50, 50))
        self.scroll = 0

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        self.back_btn.update(dt, mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = settings.width, settings.height
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("achievements"), True, GOLD)
        surface.blit(title, title.get_rect(center=(w // 2, 40)))
        achs = achievement_manager.get_all()
        unlocked_count = sum(1 for a in achs if a["unlocked"])
        count_txt = self.fonts["small"].render(f"{unlocked_count}/{len(achs)}", True, CYAN)
        surface.blit(count_txt, (w - 120, 40))

        y = 90
        for a in achs:
            if y > h - 100:
                break
            color = GREEN if a["unlocked"] else GRAY
            name = self.fonts["small"].render(a["name"], True, color)
            surface.blit(name, (80, y))
            desc = self.fonts["tiny"].render(a["desc"] + f"  (+{a['reward']})", True, GRAY)
            surface.blit(desc, (80, y + 22))
            y += 50
        self.back_btn.draw(surface)


class MapSelectMenu:
    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.buttons: List[Button] = []
        self._build()

    def _build(self) -> None:
        self.buttons.clear()
        w = settings.width
        maps = list(MAPS.keys())
        for i, name in enumerate(maps):
            col = i % 3
            row = i // 3
            x = w // 2 - 280 + col * 200
            y = 150 + row * 90
            selected = settings.current_map == name
            self.buttons.append(
                Button(
                    x, y, 180, 60, name,
                    lambda n=name: self._select(n),
                    self.fonts["medium"],
                    color=(40, 80, 60) if selected else (40, 40, 55),
                    hover_color=(60, 120, 80),
                )
            )
        self.buttons.append(
            Button(30, settings.height - 70, 140, 45, settings.t("back"), self.on_back, self.fonts["medium"], color=(80, 50, 50))
        )

    def _select(self, name: str) -> None:
        settings.current_map = name
        settings.save()
        sound_manager.play_sfx("click")
        self._build()

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        for b in self.buttons:
            b.update(dt, mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("select_map"), True, GOLD)
        surface.blit(title, title.get_rect(center=(settings.width // 2, 50)))
        for b in self.buttons:
            b.draw(surface)


class DifficultyMenu:
    def __init__(self, fonts: Dict[str, pygame.font.Font], on_back: Callable) -> None:
        self.fonts = fonts
        self.on_back = on_back
        self.buttons: List[Button] = []
        self._build()

    def _build(self) -> None:
        self.buttons.clear()
        w = settings.width
        for i, name in enumerate(DIFFICULTY.keys()):
            selected = settings.difficulty == name
            self.buttons.append(
                Button(
                    w // 2 - 120, 180 + i * 80, 240, 60, name,
                    lambda n=name: self._select(n),
                    self.fonts["medium"],
                    color=(40, 80, 60) if selected else (40, 40, 55),
                )
            )
        self.buttons.append(
            Button(30, settings.height - 70, 140, 45, settings.t("back"), self.on_back, self.fonts["medium"], color=(80, 50, 50))
        )

    def _select(self, name: str) -> None:
        settings.difficulty = name
        settings.save()
        sound_manager.play_sfx("click")
        self._build()

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        for b in self.buttons:
            b.update(dt, mouse_pos, mouse_down)

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill((15, 20, 30))
        title = self.fonts["large"].render(settings.t("difficulty"), True, GOLD)
        surface.blit(title, title.get_rect(center=(settings.width // 2, 50)))
        for b in self.buttons:
            b.draw(surface)
