"""
achievements.py - Achievement system with 50+ achievements, notifications and rewards.
"""

from __future__ import annotations

import json
import os
from typing import Dict, List, Any, Optional, Callable

from settings import ACHIEVEMENTS_FILE, DATA_DIR, ensure_data_dir
from save import load_json, save_json
from sounds import sound_manager


ACHIEVEMENT_DEFS: List[Dict[str, Any]] = [
    # Score based
    {"id": "score_100", "name": "First Steps", "desc": "Reach 100 score", "reward_coins": 20, "condition": lambda s: s.get("score", 0) >= 100},
    {"id": "score_500", "name": "Getting Good", "desc": "Reach 500 score", "reward_coins": 50, "condition": lambda s: s.get("score", 0) >= 500},
    {"id": "score_1000", "name": "Snake Master", "desc": "Reach 1000 score", "reward_coins": 100, "condition": lambda s: s.get("score", 0) >= 1000},
    {"id": "score_2000", "name": "Legendary", "desc": "Reach 2000 score", "reward_coins": 200, "condition": lambda s: s.get("score", 0) >= 2000},
    {"id": "score_5000", "name": "Unstoppable", "desc": "Reach 5000 score", "reward_coins": 500, "condition": lambda s: s.get("score", 0) >= 5000},
    # Length
    {"id": "len_10", "name": "Growing Up", "desc": "Snake length 10", "reward_coins": 15, "condition": lambda s: s.get("length", 0) >= 10},
    {"id": "len_20", "name": "Long Snake", "desc": "Snake length 20", "reward_coins": 40, "condition": lambda s: s.get("length", 0) >= 20},
    {"id": "len_40", "name": "Giant", "desc": "Snake length 40", "reward_coins": 100, "condition": lambda s: s.get("length", 0) >= 40},
    # Coins
    {"id": "coins_50", "name": "Coin Collector", "desc": "Collect 50 coins in one game", "reward_coins": 30, "condition": lambda s: s.get("coins", 0) >= 50},
    {"id": "coins_100", "name": "Rich", "desc": "Collect 100 coins in one game", "reward_coins": 80, "condition": lambda s: s.get("coins", 0) >= 100},
    # Games played
    {"id": "games_5", "name": "Regular", "desc": "Play 5 games", "reward_coins": 25, "condition": lambda s: s.get("games_played", 0) >= 5},
    {"id": "games_20", "name": "Dedicated", "desc": "Play 20 games", "reward_coins": 80, "condition": lambda s: s.get("games_played", 0) >= 20},
    {"id": "games_50", "name": "Addicted", "desc": "Play 50 games", "reward_coins": 200, "condition": lambda s: s.get("games_played", 0) >= 50},
    # Food types
    {"id": "eat_golden", "name": "Gold Digger", "desc": "Eat a golden food", "reward_coins": 20, "condition": lambda s: s.get("golden_eaten", 0) >= 1},
    {"id": "eat_rare", "name": "Lucky", "desc": "Eat a rare food", "reward_coins": 50, "condition": lambda s: s.get("rare_eaten", 0) >= 1},
    {"id": "eat_poison", "name": "Risk Taker", "desc": "Eat poison (and survive)", "reward_coins": 15, "condition": lambda s: s.get("poison_eaten", 0) >= 1},
    {"id": "no_poison", "name": "Clean", "desc": "Finish a game without eating poison", "reward_coins": 30, "condition": lambda s: s.get("poison_eaten", 0) == 0 and s.get("score", 0) >= 200},
    # Survival
    {"id": "survive_60", "name": "Survivor", "desc": "Survive 60 seconds", "reward_coins": 40, "condition": lambda s: s.get("time", 0) >= 60},
    {"id": "survive_180", "name": "Endurance", "desc": "Survive 3 minutes", "reward_coins": 100, "condition": lambda s: s.get("time", 0) >= 180},
    # Difficulty
    {"id": "hard_win", "name": "Hard Mode", "desc": "Score 500 on Hard", "reward_coins": 150, "condition": lambda s: s.get("difficulty") == "Hard" and s.get("score", 0) >= 500},
    {"id": "easy_1000", "name": "Easy Rider", "desc": "Score 1000 on Easy", "reward_coins": 50, "condition": lambda s: s.get("difficulty") == "Easy" and s.get("score", 0) >= 1000},
    # Maps
    {"id": "map_forest", "name": "Forest Explorer", "desc": "Play on Forest map", "reward_coins": 10, "condition": lambda s: s.get("map") == "Forest"},
    {"id": "map_snow", "name": "Snow Walker", "desc": "Play on Snow map", "reward_coins": 10, "condition": lambda s: s.get("map") == "Snow"},
    {"id": "map_desert", "name": "Desert Nomad", "desc": "Play on Desert map", "reward_coins": 10, "condition": lambda s: s.get("map") == "Desert"},
    {"id": "map_space", "name": "Space Cadet", "desc": "Play on Space map", "reward_coins": 15, "condition": lambda s: s.get("map") == "Space"},
    {"id": "map_fire", "name": "Fire Walker", "desc": "Play on Fire map", "reward_coins": 15, "condition": lambda s: s.get("map") == "Fire"},
    {"id": "map_city", "name": "City Slicker", "desc": "Play on City map", "reward_coins": 15, "condition": lambda s: s.get("map") == "City"},
    # Skins
    {"id": "skin_fire", "name": "On Fire", "desc": "Unlock Fire skin", "reward_coins": 0, "condition": lambda s: "Fire" in s.get("unlocked_skins", [])},
    {"id": "skin_neon", "name": "Neon Lights", "desc": "Unlock Neon skin", "reward_coins": 0, "condition": lambda s: "Neon" in s.get("unlocked_skins", [])},
    {"id": "skin_gold", "name": "Golden Touch", "desc": "Unlock Golden skin", "reward_coins": 0, "condition": lambda s: "Golden" in s.get("unlocked_skins", [])},
    # Combat
    {"id": "enemy_hit", "name": "Close Call", "desc": "Collide with an enemy and survive", "reward_coins": 20, "condition": lambda s: s.get("enemy_hits", 0) >= 1},
    {"id": "no_enemy", "name": "Peaceful", "desc": "Score 300 without hitting enemies", "reward_coins": 40, "condition": lambda s: s.get("enemy_hits", 0) == 0 and s.get("score", 0) >= 300},
    # Level / XP
    {"id": "level_5", "name": "Rising Star", "desc": "Reach player level 5", "reward_coins": 50, "condition": lambda s: s.get("player_level", 1) >= 5},
    {"id": "level_10", "name": "Experienced", "desc": "Reach player level 10", "reward_coins": 100, "condition": lambda s: s.get("player_level", 1) >= 10},
    {"id": "level_20", "name": "Veteran Player", "desc": "Reach player level 20", "reward_coins": 250, "condition": lambda s: s.get("player_level", 1) >= 20},
    # Special
    {"id": "first_death", "name": "Ouch", "desc": "Die for the first time", "reward_coins": 5, "condition": lambda s: s.get("deaths", 0) >= 1},
    {"id": "boss_kill", "name": "Boss Slayer", "desc": "Reach a boss stage", "reward_coins": 100, "condition": lambda s: s.get("boss_reached", False)},
    {"id": "perfect_start", "name": "Perfect Start", "desc": "Eat 5 foods without dying", "reward_coins": 25, "condition": lambda s: s.get("foods_eaten", 0) >= 5 and s.get("deaths", 0) == 0},
    {"id": "speed_demon", "name": "Speed Demon", "desc": "Use speed boost food 3 times", "reward_coins": 30, "condition": lambda s: s.get("speed_eaten", 0) >= 3},
    {"id": "double_trouble", "name": "Double Trouble", "desc": "Activate double score", "reward_coins": 25, "condition": lambda s: s.get("double_activated", 0) >= 1},
    {"id": "shopaholic", "name": "Shopaholic", "desc": "Buy 5 items from shop", "reward_coins": 50, "condition": lambda s: s.get("items_bought", 0) >= 5},
    {"id": "full_lives", "name": "Full Health", "desc": "Have max lives", "reward_coins": 20, "condition": lambda s: s.get("lives", 0) >= 5},
    {"id": "combo_10", "name": "Combo King", "desc": "Eat 10 foods in a row quickly", "reward_coins": 60, "condition": lambda s: s.get("combo", 0) >= 10},
    {"id": "night_owl", "name": "Night Owl", "desc": "Play after midnight (system time)", "reward_coins": 15, "condition": lambda s: s.get("night_owl", False)},
    {"id": "all_maps", "name": "Cartographer", "desc": "Play all maps", "reward_coins": 100, "condition": lambda s: len(s.get("maps_played", [])) >= 6},
    {"id": "all_skins", "name": "Fashionista", "desc": "Unlock all skins", "reward_coins": 300, "condition": lambda s: len(s.get("unlocked_skins", [])) >= 6},
    {"id": "millionaire", "name": "Millionaire", "desc": "Own 1000 coins", "reward_coins": 0, "condition": lambda s: s.get("total_coins", 0) >= 1000},
    {"id": "pacifist", "name": "Pacifist", "desc": "Complete a level without enemies spawning", "reward_coins": 40, "condition": lambda s: s.get("enemies_spawned", 0) == 0 and s.get("score", 0) >= 150},
    {"id": "daredevil", "name": "Daredevil", "desc": "Survive with 1 life for 30s", "reward_coins": 50, "condition": lambda s: s.get("low_life_time", 0) >= 30},
    {"id": "collector", "name": "Collector", "desc": "Unlock 20 achievements", "reward_coins": 100, "condition": lambda s: len(s.get("unlocked", [])) >= 20},
]


class AchievementManager:
    """Tracks and unlocks achievements."""

    def __init__(self) -> None:
        self.unlocked: List[str] = []
        self.stats: Dict[str, Any] = {}
        self.pending_notifications: List[str] = []
        self._load()

    def _load(self) -> None:
        data = load_json(ACHIEVEMENTS_FILE, default={"unlocked": [], "stats": {}})
        self.unlocked = data.get("unlocked", [])
        self.stats = data.get("stats", {})

    def _save(self) -> None:
        save_json(ACHIEVEMENTS_FILE, {"unlocked": self.unlocked, "stats": self.stats})

    def update_stats(self, **kwargs: Any) -> None:
        """Merge new stats and check achievements."""
        for k, v in kwargs.items():
            if isinstance(v, (int, float)) and k in self.stats and isinstance(self.stats[k], (int, float)):
                # For cumulative, use max or sum depending on key
                if k in ("score", "length", "coins", "time", "combo", "player_level"):
                    self.stats[k] = max(self.stats.get(k, 0), v)
                else:
                    self.stats[k] = self.stats.get(k, 0) + v if isinstance(v, int) else v
            else:
                self.stats[k] = v
        self.check()

    def set_stat(self, key: str, value: Any) -> None:
        self.stats[key] = value
        self.check()

    def check(self) -> List[str]:
        """Check all achievements and unlock new ones. Returns newly unlocked ids."""
        newly = []
        for ach in ACHIEVEMENT_DEFS:
            aid = ach["id"]
            if aid in self.unlocked:
                continue
            try:
                if ach["condition"](self.stats):
                    self.unlocked.append(aid)
                    newly.append(aid)
                    coins = ach.get("reward_coins", 0)
                    if coins > 0:
                        from settings import settings as gs
                        gs.coins += coins
                        gs.save()
                    self.pending_notifications.append(
                        f"Achievement: {ach['name']} (+{coins} coins)" if coins else f"Achievement: {ach['name']}"
                    )
                    sound_manager.play_sfx("achievement")
            except Exception:
                continue
        if newly:
            self._save()
        return newly

    def get_all(self) -> List[Dict[str, Any]]:
        result = []
        for ach in ACHIEVEMENT_DEFS:
            result.append(
                {
                    "id": ach["id"],
                    "name": ach["name"],
                    "desc": ach["desc"],
                    "reward": ach.get("reward_coins", 0),
                    "unlocked": ach["id"] in self.unlocked,
                }
            )
        return result

    def pop_notification(self) -> Optional[str]:
        if self.pending_notifications:
            return self.pending_notifications.pop(0)
        return None


# Global
achievement_manager = AchievementManager()
