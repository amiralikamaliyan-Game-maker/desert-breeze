"""
effects.py - Particles, weather, screen shake, glow and visual effects.
"""

from __future__ import annotations

import math
import random
from typing import List, Tuple, Optional

import pygame

from settings import settings, CELL_SIZE


class Particle:
    """Single particle for explosion / eat effects."""

    def __init__(
        self,
        x: float,
        y: float,
        color: Tuple[int, int, int],
        velocity: Tuple[float, float],
        lifetime: float = 0.8,
        size: float = 4.0,
    ) -> None:
        self.x = x
        self.y = y
        self.color = color
        self.vx, self.vy = velocity
        self.lifetime = lifetime
        self.max_lifetime = lifetime
        self.size = size
        self.alive = True

    def update(self, dt: float) -> None:
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += 120 * dt  # gravity-ish
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        if not self.alive:
            return
        alpha = max(0, min(255, int(255 * (self.lifetime / self.max_lifetime))))
        size = max(1, int(self.size * (self.lifetime / self.max_lifetime)))
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.color, alpha), (size, size), size)
        surface.blit(s, (int(self.x + offset[0] - size), int(self.y + offset[1] - size)))


class ParticleSystem:
    """Manages multiple particles."""

    def __init__(self) -> None:
        self.particles: List[Particle] = []

    def emit(
        self,
        x: float,
        y: float,
        color: Tuple[int, int, int],
        count: int = 12,
        speed: float = 80.0,
        lifetime: float = 0.7,
    ) -> None:
        for _ in range(count):
            angle = random.uniform(0, math.pi * 2)
            vel = (
                math.cos(angle) * random.uniform(speed * 0.3, speed),
                math.sin(angle) * random.uniform(speed * 0.3, speed),
            )
            self.particles.append(
                Particle(x, y, color, vel, lifetime=lifetime, size=random.uniform(2, 5))
            )

    def update(self, dt: float) -> None:
        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.alive]

    def draw(self, surface: pygame.Surface, offset: Tuple[float, float] = (0, 0)) -> None:
        for p in self.particles:
            p.draw(surface, offset)

    def clear(self) -> None:
        self.particles.clear()


class WeatherSystem:
    """Rain, snow, stars, fog effects based on map."""

    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.particles: List[dict] = []
        self.weather_type = "none"
        self._init_particles()

    def set_weather(self, weather: str) -> None:
        if weather != self.weather_type:
            self.weather_type = weather
            self._init_particles()

    def _init_particles(self) -> None:
        self.particles.clear()
        count = 80 if settings.graphics_quality == "High" else 40
        if self.weather_type == "rain":
            for _ in range(count):
                self.particles.append(
                    {
                        "x": random.uniform(0, self.width),
                        "y": random.uniform(-self.height, self.height),
                        "speed": random.uniform(300, 500),
                        "len": random.uniform(8, 16),
                    }
                )
        elif self.weather_type == "snow":
            for _ in range(count):
                self.particles.append(
                    {
                        "x": random.uniform(0, self.width),
                        "y": random.uniform(-self.height, self.height),
                        "speed": random.uniform(40, 100),
                        "size": random.uniform(2, 5),
                        "drift": random.uniform(-20, 20),
                    }
                )
        elif self.weather_type == "stars":
            for _ in range(count * 2):
                self.particles.append(
                    {
                        "x": random.uniform(0, self.width),
                        "y": random.uniform(0, self.height),
                        "size": random.uniform(1, 3),
                        "twinkle": random.uniform(0, math.pi * 2),
                        "speed": random.uniform(1, 3),
                    }
                )
        elif self.weather_type == "fog":
            for _ in range(20):
                self.particles.append(
                    {
                        "x": random.uniform(-100, self.width),
                        "y": random.uniform(0, self.height),
                        "w": random.uniform(80, 200),
                        "h": random.uniform(30, 60),
                        "speed": random.uniform(10, 30),
                        "alpha": random.randint(20, 50),
                    }
                )

    def update(self, dt: float) -> None:
        if self.weather_type == "rain":
            for p in self.particles:
                p["y"] += p["speed"] * dt
                if p["y"] > self.height:
                    p["y"] = random.uniform(-50, 0)
                    p["x"] = random.uniform(0, self.width)
        elif self.weather_type == "snow":
            for p in self.particles:
                p["y"] += p["speed"] * dt
                p["x"] += p["drift"] * dt
                if p["y"] > self.height:
                    p["y"] = random.uniform(-20, 0)
                    p["x"] = random.uniform(0, self.width)
                if p["x"] < 0:
                    p["x"] = self.width
                elif p["x"] > self.width:
                    p["x"] = 0
        elif self.weather_type == "stars":
            for p in self.particles:
                p["twinkle"] += p["speed"] * dt
        elif self.weather_type == "fog":
            for p in self.particles:
                p["x"] += p["speed"] * dt
                if p["x"] > self.width + 100:
                    p["x"] = -p["w"]
                    p["y"] = random.uniform(0, self.height)

    def draw(self, surface: pygame.Surface) -> None:
        if self.weather_type == "rain":
            for p in self.particles:
                pygame.draw.line(
                    surface,
                    (150, 180, 220),
                    (int(p["x"]), int(p["y"])),
                    (int(p["x"]), int(p["y"] + p["len"])),
                    1,
                )
        elif self.weather_type == "snow":
            for p in self.particles:
                pygame.draw.circle(
                    surface,
                    (230, 240, 255),
                    (int(p["x"]), int(p["y"])),
                    int(p["size"]),
                )
        elif self.weather_type == "stars":
            for p in self.particles:
                alpha = int(128 + 127 * math.sin(p["twinkle"]))
                s = pygame.Surface((int(p["size"] * 2), int(p["size"] * 2)), pygame.SRCALPHA)
                pygame.draw.circle(
                    s,
                    (255, 255, 255, alpha),
                    (int(p["size"]), int(p["size"])),
                    int(p["size"]),
                )
                surface.blit(s, (int(p["x"]), int(p["y"])))
        elif self.weather_type == "fog":
            for p in self.particles:
                s = pygame.Surface((int(p["w"]), int(p["h"])), pygame.SRCALPHA)
                s.fill((180, 180, 200, p["alpha"]))
                surface.blit(s, (int(p["x"]), int(p["y"])))


class ScreenShake:
    """Camera shake effect."""

    def __init__(self) -> None:
        self.intensity = 0.0
        self.duration = 0.0
        self.timer = 0.0
        self.offset = (0.0, 0.0)

    def shake(self, intensity: float = 8.0, duration: float = 0.3) -> None:
        self.intensity = intensity
        self.duration = duration
        self.timer = duration

    def update(self, dt: float) -> None:
        if self.timer > 0:
            self.timer -= dt
            t = self.timer / self.duration if self.duration > 0 else 0
            mag = self.intensity * t
            self.offset = (
                random.uniform(-mag, mag),
                random.uniform(-mag, mag),
            )
        else:
            self.offset = (0.0, 0.0)

    def get_offset(self) -> Tuple[float, float]:
        return self.offset


def draw_glow(
    surface: pygame.Surface,
    pos: Tuple[int, int],
    radius: int,
    color: Tuple[int, int, int],
    intensity: int = 3,
) -> None:
    """Simple glow effect around a point."""
    if settings.graphics_quality == "Low":
        return
    for i in range(intensity, 0, -1):
        alpha = 30 * i
        s = pygame.Surface((radius * 2 * i, radius * 2 * i), pygame.SRCALPHA)
        pygame.draw.circle(
            s,
            (*color, min(255, alpha)),
            (radius * i, radius * i),
            radius * i,
        )
        surface.blit(
            s,
            (pos[0] - radius * i, pos[1] - radius * i),
            special_flags=pygame.BLEND_RGBA_ADD,
        )


def draw_shadow(
    surface: pygame.Surface,
    rect: pygame.Rect,
    offset: int = 3,
    alpha: int = 80,
) -> None:
    """Draw a soft shadow under a rectangle."""
    if settings.graphics_quality == "Low":
        return
    s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    s.fill((0, 0, 0, alpha))
    surface.blit(s, (rect.x + offset, rect.y + offset))
