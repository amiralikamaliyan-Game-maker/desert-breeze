"""
save.py - Save / load system for game state, records and player progress.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

from settings import (
    SAVE_FILE,
    RECORDS_FILE,
    PLAYER_DATA_FILE,
    DATA_DIR,
    ensure_data_dir,
)


def save_json(path: str, data: Any) -> bool:
    """Write data to JSON file safely."""
    ensure_data_dir()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except OSError as e:
        print(f"[Save] Error writing {path}: {e}")
        return False


def load_json(path: str, default: Any = None) -> Any:
    """Load JSON file or return default."""
    if not os.path.exists(path):
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"[Save] Error reading {path}: {e}")
        return default if default is not None else {}


# ---------------------------------------------------------------------------
# Game state (continue last game)
# ---------------------------------------------------------------------------
def save_game_state(state: Dict[str, Any]) -> bool:
    """Save current game state for continue feature."""
    return save_json(SAVE_FILE, state)


def load_game_state() -> Optional[Dict[str, Any]]:
    """Load previously saved game state."""
    data = load_json(SAVE_FILE, default=None)
    if data and isinstance(data, dict) and data.get("valid"):
        return data
    return None


def clear_game_state() -> None:
    """Remove saved game state."""
    if os.path.exists(SAVE_FILE):
        try:
            os.remove(SAVE_FILE)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# High scores / records
# ---------------------------------------------------------------------------
def load_records() -> List[Dict[str, Any]]:
    """Return sorted list of high scores."""
    data = load_json(RECORDS_FILE, default=[])
    if not isinstance(data, list):
        return []
    return sorted(data, key=lambda x: x.get("score", 0), reverse=True)[:20]


def add_record(
    score: int,
    coins: int,
    map_name: str,
    difficulty: str,
    player_name: str = "Player",
) -> None:
    """Add a new high score entry."""
    records = load_records()
    records.append(
        {
            "score": score,
            "coins": coins,
            "map": map_name,
            "difficulty": difficulty,
            "name": player_name,
        }
    )
    records = sorted(records, key=lambda x: x.get("score", 0), reverse=True)[:20]
    save_json(RECORDS_FILE, records)


def get_best_score() -> int:
    """Return the highest recorded score."""
    records = load_records()
    if records:
        return records[0].get("score", 0)
    return 0


# ---------------------------------------------------------------------------
# Player persistent data (level, xp, etc.)
# ---------------------------------------------------------------------------
def load_player_data() -> Dict[str, Any]:
    """Load player progress."""
    default = {
        "level": 1,
        "xp": 0,
        "rank": "Novice",
        "total_games": 0,
        "total_score": 0,
        "total_coins_earned": 0,
        "achievements_unlocked": [],
        "daily_missions": {},
        "weekly_missions": {},
    }
    data = load_json(PLAYER_DATA_FILE, default=default)
    for k, v in default.items():
        if k not in data:
            data[k] = v
    return data


def save_player_data(data: Dict[str, Any]) -> bool:
    """Save player progress."""
    return save_json(PLAYER_DATA_FILE, data)


def add_xp(amount: int) -> Dict[str, Any]:
    """Add XP and handle level-ups. Returns updated player data."""
    data = load_player_data()
    data["xp"] = data.get("xp", 0) + amount
    data["total_score"] = data.get("total_score", 0) + amount

    # Level formula: level * 100 XP needed
    while data["xp"] >= data["level"] * 100:
        data["xp"] -= data["level"] * 100
        data["level"] += 1
        # Update rank
        lvl = data["level"]
        if lvl >= 50:
            data["rank"] = "Legend"
        elif lvl >= 30:
            data["rank"] = "Master"
        elif lvl >= 20:
            data["rank"] = "Expert"
        elif lvl >= 10:
            data["rank"] = "Veteran"
        elif lvl >= 5:
            data["rank"] = "Adept"
        else:
            data["rank"] = "Novice"

    save_player_data(data)
    return data
