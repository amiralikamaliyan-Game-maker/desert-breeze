"""
ui.py - Professional UI components: buttons, labels, panels, animations.
"""

from __future__ import annotations

import math
from typing import Callable, Optional, Tuple, List

import pygame

from settings import settings, WHITE, BLACK, GRAY, DARK_GRAY, LIGHT_GRAY, GOLD, GREEN, CYAN
from sounds import sound_manager


class Button:
    """Animated graphical button with hover and click effects."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        text: str,
        callback: Optional[Callable] = None,
        font: Optional[pygame.font.Font] = None,
        color: Tuple[int, int, int] = (50, 120, 80),
        hover_color: Tuple[int, int, int] = (70, 160, 100),
        text_color: Tuple[int, int, int] = WHITE,
        border_radius: int = 12,
    ) -> None:
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.callback = callback
        self.font = font
        self.color = color
        self.hover_color = hover_color
        self.text_color = text_color
        self.border_radius = border_radius
        self.hovered = False
        self.pressed = False
        self.scale = 1.0
        self.target_scale = 1.0
        self.enabled = True
        self.alpha = 255

    def update(self, dt: float, mouse_pos: Tuple[int, int], mouse_down: bool) -> None:
        if not self.enabled:
            self.hovered = False
            self.pressed = False
            return
        self.hovered = self.rect.collidepoint(mouse_pos)
        was_pressed = self.pressed
        self.pressed = self.hovered and mouse_down

        self.target_scale = 1.08 if self.hovered else 1.0
        if self.pressed:
            self.target_scale = 0.95
        # Smooth scale
        self.scale += (self.target_scale - self.scale) * min(1.0, dt * 12)

        if was_pressed and not mouse_down and self.hovered:
            sound_manager.play_sfx("click")
            if self.callback:
                self.callback()

    def draw(self, surface: pygame.Surface) -> None:
        if self.alpha <= 0:
            return
        # Scaled rect
        w = int(self.rect.width * self.scale)
        h = int(self.rect.height * self.scale)
        x = self.rect.centerx - w // 2
        y = self.rect.centery - h // 2
        draw_rect = pygame.Rect(x, y, w, h)

        color = self.hover_color if self.hovered else self.color
        if not self.enabled:
            color = GRAY

        # Shadow
        shadow = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(shadow, (0, 0, 0, 60), shadow.get_rect(), border_radius=self.border_radius)
        surface.blit(shadow, (x + 3, y + 3))

        # Button body
        btn_surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(btn_surf, (*color, self.alpha), btn_surf.get_rect(), border_radius=self.border_radius)
        # Highlight
        if self.hovered and self.enabled:
            pygame.draw.rect(
                btn_surf,
                (255, 255, 255, 40),
                pygame.Rect(0, 0, w, h // 2),
                border_radius=self.border_radius,
            )
        surface.blit(btn_surf, (x, y))

        # Text
        if self.font:
            text_surf = self.font.render(self.text, True, self.text_color)
            text_surf.set_alpha(self.alpha)
            text_rect = text_surf.get_rect(center=draw_rect.center)
            surface.blit(text_surf, text_rect)


class Label:
    """Simple text label."""

    def __init__(
        self,
        x: int,
        y: int,
        text: str,
        font: Optional[pygame.font.Font] = None,
        color: Tuple[int, int, int] = WHITE,
        center: bool = False,
    ) -> None:
        self.x = x
        self.y = y
        self.text = text
        self.font = font
        self.color = color
        self.center = center

    def draw(self, surface: pygame.Surface) -> None:
        if not self.font:
            return
        surf = self.font.render(self.text, True, self.color)
        if self.center:
            rect = surf.get_rect(center=(self.x, self.y))
        else:
            rect = surf.get_rect(topleft=(self.x, self.y))
        surface.blit(surf, rect)


class Panel:
    """Semi-transparent panel with optional title."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        height: int,
        title: str = "",
        font: Optional[pygame.font.Font] = None,
        alpha: int = 180,
    ) -> None:
        self.rect = pygame.Rect(x, y, width, height)
        self.title = title
        self.font = font
        self.alpha = alpha

    def draw(self, surface: pygame.Surface) -> None:
        s = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        pygame.draw.rect(s, (20, 20, 30, self.alpha), s.get_rect(), border_radius=16)
        pygame.draw.rect(s, (80, 80, 120, 100), s.get_rect(), width=2, border_radius=16)
        surface.blit(s, self.rect.topleft)
        if self.title and self.font:
            title_surf = self.font.render(self.title, True, GOLD)
            title_rect = title_surf.get_rect(midtop=(self.rect.centerx, self.rect.y + 12))
            surface.blit(title_surf, title_rect)


class Slider:
    """Volume / value slider."""

    def __init__(
        self,
        x: int,
        y: int,
        width: int,
        value: float = 0.5,
        min_val: float = 0.0,
        max_val: float = 1.0,
        callback: Optional[Callable[[float], None]] = None,
    ) -> None:
        self.rect = pygame.Rect(x, y, width, 12)
        self.value = value
        self.min_val = min_val
        self.max_val = max_val
        self.callback = callback
        self.dragging = False
        self.handle_radius = 10

    def update(self, mouse_pos: Tuple[int, int], mouse_down: bool) -> None:
        handle_x = self.rect.x + int(
            (self.value - self.min_val) / (self.max_val - self.min_val) * self.rect.width
        )
        handle_rect = pygame.Rect(
            handle_x - self.handle_radius,
            self.rect.centery - self.handle_radius,
            self.handle_radius * 2,
            self.handle_radius * 2,
        )
        if mouse_down and (handle_rect.collidepoint(mouse_pos) or self.rect.collidepoint(mouse_pos)):
            self.dragging = True
        if not mouse_down:
            self.dragging = False
        if self.dragging:
            rel = (mouse_pos[0] - self.rect.x) / max(1, self.rect.width)
            rel = max(0.0, min(1.0, rel))
            self.value = self.min_val + rel * (self.max_val - self.min_val)
            if self.callback:
                self.callback(self.value)

    def draw(self, surface: pygame.Surface) -> None:
        # Track
        pygame.draw.rect(surface, DARK_GRAY, self.rect, border_radius=6)
        filled_w = int(
            (self.value - self.min_val) / (self.max_val - self.min_val) * self.rect.width
        )
        filled = pygame.Rect(self.rect.x, self.rect.y, filled_w, self.rect.height)
        pygame.draw.rect(surface, CYAN, filled, border_radius=6)
        # Handle
        hx = self.rect.x + filled_w
        pygame.draw.circle(surface, WHITE, (hx, self.rect.centery), self.handle_radius)
        pygame.draw.circle(surface, CYAN, (hx, self.rect.centery), self.handle_radius - 3)


class Notification:
    """Achievement / mission notification popup."""

    def __init__(self, text: str, font: Optional[pygame.font.Font] = None, duration: float = 3.0) -> None:
        self.text = text
        self.font = font
        self.duration = duration
        self.timer = duration
        self.y_offset = -60
        self.alive = True

    def update(self, dt: float) -> None:
        self.timer -= dt
        if self.timer > self.duration - 0.4:
            self.y_offset += 150 * dt
        elif self.timer < 0.4:
            self.y_offset -= 150 * dt
        if self.timer <= 0:
            self.alive = False

    def draw(self, surface: pygame.Surface, screen_width: int) -> None:
        if not self.font or not self.alive:
            return
        text_surf = self.font.render(self.text, True, GOLD)
        padding = 16
        w = text_surf.get_width() + padding * 2
        h = text_surf.get_height() + padding
        x = (screen_width - w) // 2
        y = 20 + int(self.y_offset)
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(s, (30, 30, 50, 220), s.get_rect(), border_radius=10)
        pygame.draw.rect(s, GOLD, s.get_rect(), width=2, border_radius=10)
        surface.blit(s, (x, y))
        surface.blit(text_surf, (x + padding, y + padding // 2))


class MenuAnimator:
    """Handles fade-in / fade-out for menu transitions."""

    def __init__(self) -> None:
        self.alpha = 0
        self.target_alpha = 255
        self.speed = 400
        self.done = False

    def fade_in(self) -> None:
        self.alpha = 0
        self.target_alpha = 255
        self.done = False

    def fade_out(self) -> None:
        self.target_alpha = 0
        self.done = False

    def update(self, dt: float) -> None:
        if abs(self.alpha - self.target_alpha) < 2:
            self.alpha = self.target_alpha
            self.done = True
            return
        direction = 1 if self.target_alpha > self.alpha else -1
        self.alpha += direction * self.speed * dt
        self.alpha = max(0, min(255, self.alpha))

    def draw_overlay(self, surface: pygame.Surface) -> None:
        if self.alpha >= 255:
            return
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 255 - int(self.alpha)))
        surface.blit(overlay, (0, 0))
