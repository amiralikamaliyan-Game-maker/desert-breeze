"""
game.py - Core gameplay loop, HUD, pause, game over, victory, countdown.
"""

from __future__ import annotations

import time
from typing import Dict, Optional, Tuple, Any, Callable

import pygame

from settings import (
    settings,
    CELL_SIZE,
    GRID_WIDTH,
    GRID_HEIGHT,
    DIFFICULTY,
    WHITE,
    GOLD,
    RED,
    GREEN,
    CYAN,
    GRAY,
    BLACK,
)
from snake import Snake
from food import FoodManager
from enemy import EnemyManager
from maps import GameMap
from effects import ParticleSystem, WeatherSystem, ScreenShake
from sounds import sound_manager
from save import save_game_state, clear_game_state, add_record, add_xp, get_best_score
from achievements import achievement_manager
from ui import Button, Notification


class Game:
    """Main game session."""

    def __init__(
        self,
        fonts: Dict[str, pygame.font.Font],
        on_quit_to_menu: Callable,
        continue_state: Optional[Dict] = None,
    ) -> None:
        self.fonts = fonts
        self.on_quit_to_menu = on_quit_to_menu

        diff = DIFFICULTY.get(settings.difficulty, DIFFICULTY["Medium"])
        self.diff = diff

        self.snake = Snake()
        self.snake.lives = diff["lives"]
        self.snake.base_speed = diff["speed"]

        self.food_mgr = FoodManager()
        self.enemy_mgr = EnemyManager()
        self.game_map = GameMap(settings.current_map)
        self.particles = ParticleSystem()
        self.weather = WeatherSystem(settings.width, settings.height)
        self.weather.set_weather(self.game_map.weather)
        self.shake = ScreenShake()

        self.score = 0
        self.coins = 0
        self.level = 1
        self.time_played = 0.0
        self.paused = False
        self.game_over = False
        self.victory = False
        self.countdown = 3.0  # 3..2..1
        self.state = "countdown"  # countdown | playing | paused | gameover | victory

        self.double_score_timer = 0.0
        self.slow_enemy_timer = 0.0
        self.speed_boost_timer = 0.0
        self.coin_magnet_timer = 0.0

        self.foods_eaten = 0
        self.golden_eaten = 0
        self.rare_eaten = 0
        self.poison_eaten = 0
        self.speed_eaten = 0
        self.enemy_hits = 0
        self.combo = 0
        self.combo_timer = 0.0

        self.notifications: list = []
        self.best_score = get_best_score()
        self.auto_save_timer = 0.0

        # Buttons for pause / game over
        self.pause_buttons: list = []
        self.gameover_buttons: list = []
        self._build_overlay_buttons()

        if continue_state:
            self._load_state(continue_state)
        else:
            self._initial_spawn()

        sound_manager.play_music(settings.current_map)

    def _build_overlay_buttons(self) -> None:
        w, h = settings.width, settings.height
        self.pause_buttons = [
            Button(w // 2 - 100, h // 2 - 20, 200, 45, settings.t("resume"), self._resume, self.fonts["medium"]),
            Button(w // 2 - 100, h // 2 + 40, 200, 45, settings.t("restart"), self._restart, self.fonts["medium"]),
            Button(w // 2 - 100, h // 2 + 100, 200, 45, settings.t("back"), self.on_quit_to_menu, self.fonts["medium"], color=(80, 50, 50)),
        ]
        self.gameover_buttons = [
            Button(w // 2 - 100, h // 2 + 60, 200, 45, settings.t("restart"), self._restart, self.fonts["medium"]),
            Button(w // 2 - 100, h // 2 + 120, 200, 45, settings.t("back"), self.on_quit_to_menu, self.fonts["medium"], color=(80, 50, 50)),
        ]

    def _initial_spawn(self) -> None:
        occupied = self.game_map.get_occupied() | set(self.snake.body)
        self.food_mgr.spawn(occupied)
        self.food_mgr.spawn(occupied | self.food_mgr.get_occupied())

    def _load_state(self, state: Dict) -> None:
        self.score = state.get("score", 0)
        self.coins = state.get("coins", 0)
        self.level = state.get("level", 1)
        self.time_played = state.get("time", 0)
        self.snake.lives = state.get("lives", 3)
        self.state = "countdown"
        self.countdown = 2.0

    def _resume(self) -> None:
        self.paused = False
        self.state = "playing"
        sound_manager.play_sfx("click")

    def _restart(self) -> None:
        clear_game_state()
        self.__init__(self.fonts, self.on_quit_to_menu)
        sound_manager.play_sfx("click")

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_p and self.state == "playing":
                self.paused = True
                self.state = "paused"
                sound_manager.play_sfx("pause")
            elif event.key == pygame.K_p and self.state == "paused":
                self._resume()
            elif event.key == pygame.K_r:
                self._restart()
            elif event.key == pygame.K_ESCAPE:
                if self.state in ("playing", "paused"):
                    self._save_current()
                    self.on_quit_to_menu()
                elif self.state in ("gameover", "victory"):
                    self.on_quit_to_menu()
            # Movement
            elif self.state == "playing":
                if event.key in (pygame.K_UP, pygame.K_w):
                    self.snake.set_direction(0, -1)
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    self.snake.set_direction(0, 1)
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    self.snake.set_direction(-1, 0)
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.snake.set_direction(1, 0)
                # Use inventory items
                elif event.key == pygame.K_1:
                    self._use_item("extra_life")
                elif event.key == pygame.K_2:
                    self._use_item("shield")
                elif event.key == pygame.K_3:
                    self._use_item("double_score")

        # Gamepad
        if event.type == pygame.JOYHATMOTION:
            hx, hy = event.value
            if self.state == "playing":
                if hy == 1:
                    self.snake.set_direction(0, -1)
                elif hy == -1:
                    self.snake.set_direction(0, 1)
                elif hx == -1:
                    self.snake.set_direction(-1, 0)
                elif hx == 1:
                    self.snake.set_direction(1, 0)

    def _use_item(self, item_id: str) -> None:
        inv = settings.inventory
        if inv.get(item_id, 0) <= 0:
            return
        inv[item_id] -= 1
        settings.inventory = inv
        settings.save()
        if item_id == "extra_life":
            self.snake.lives += 1
        elif item_id == "shield":
            self.snake.shield_active = True
        elif item_id == "double_score":
            self.double_score_timer = 25.0
        elif item_id == "slow_enemy":
            self.slow_enemy_timer = 30.0
        elif item_id == "speed_boost":
            self.speed_boost_timer = 15.0
            self.snake.speed_multiplier = 1.4
        elif item_id == "coin_magnet":
            self.coin_magnet_timer = 20.0
        sound_manager.play_sfx("powerup")

    def update(self, dt: float, mouse_pos, mouse_down: bool) -> None:
        # Notifications
        for n in self.notifications:
            n.update(dt)
        self.notifications = [n for n in self.notifications if n.alive]
        notif = achievement_manager.pop_notification()
        if notif:
            self.notifications.append(Notification(notif, self.fonts["small"]))

        if self.state == "countdown":
            self.countdown -= dt
            if self.countdown <= 0:
                self.state = "playing"
                self.countdown = 0
            return

        if self.state == "paused":
            for b in self.pause_buttons:
                b.update(dt, mouse_pos, mouse_down)
            return

        if self.state in ("gameover", "victory"):
            for b in self.gameover_buttons:
                b.update(dt, mouse_pos, mouse_down)
            self.particles.update(dt)
            return

        if self.state != "playing":
            return

        # Timers
        self.time_played += dt
        self.auto_save_timer += dt
        if self.auto_save_timer > 10.0:
            self.auto_save_timer = 0.0
            self._save_current()

        if self.double_score_timer > 0:
            self.double_score_timer -= dt
        if self.slow_enemy_timer > 0:
            self.slow_enemy_timer -= dt
        if self.speed_boost_timer > 0:
            self.speed_boost_timer -= dt
            if self.speed_boost_timer <= 0:
                self.snake.speed_multiplier = 1.0
        if self.coin_magnet_timer > 0:
            self.coin_magnet_timer -= dt
        if self.combo_timer > 0:
            self.combo_timer -= dt
            if self.combo_timer <= 0:
                self.combo = 0

        # Speed increases with score
        extra = (self.score // 100) * self.diff["speed_increase"]
        self.snake.base_speed = self.diff["speed"] + extra

        occupied = (
            self.game_map.get_occupied()
            | set(self.snake.body)
            | self.food_mgr.get_occupied()
            | self.enemy_mgr.get_occupied()
        )

        self.snake.update(dt)
        self.food_mgr.update(dt, occupied, self.diff["food_spawn_rate"])
        enemy_mult = 0.5 if self.slow_enemy_timer > 0 else self.diff["enemy_speed"]
        self.enemy_mgr.update(
            dt,
            self.snake.get_head(),
            self.game_map.get_occupied(),
            set(self.snake.body),
            self.level,
            enemy_mult,
        )
        self.game_map.update(dt)
        self.weather.update(dt)
        self.particles.update(dt)
        self.shake.update(dt)

        # Food collision
        food = self.food_mgr.check_collision(self.snake.get_head())
        if food:
            self._on_eat(food)

        # Obstacle collision
        if self.game_map.is_blocked(self.snake.get_head()):
            self._on_hit()

        # Enemy collision
        if self.enemy_mgr.check_collision(self.snake.get_head()):
            self.enemy_hits += 1
            self._on_hit()

        # Level progression
        if self.score >= self.level * 300:
            self.level += 1
            sound_manager.play_sfx("levelup")
            if self.level % 5 == 0:
                # Boss stage indicator
                achievement_manager.update_stats(boss_reached=True)
                self.notifications.append(
                    Notification(f"BOSS STAGE {self.level}!", self.fonts["medium"], 2.5)
                )

        # Check death
        if not self.snake.alive:
            self._trigger_game_over()

        # Victory after high level (optional)
        if self.level >= 15 and self.score >= 5000:
            self._trigger_victory()

        # Achievements live update
        achievement_manager.update_stats(
            score=self.score,
            length=len(self.snake.body),
            coins=self.coins,
            time=self.time_played,
            level=self.level,
            foods_eaten=self.foods_eaten,
            golden_eaten=self.golden_eaten,
            rare_eaten=self.rare_eaten,
            poison_eaten=self.poison_eaten,
            speed_eaten=self.speed_eaten,
            enemy_hits=self.enemy_hits,
            combo=self.combo,
            difficulty=settings.difficulty,
            map=settings.current_map,
            lives=self.snake.lives,
            player_level=settings.player_level,
            unlocked_skins=settings.unlocked_skins,
        )

    def _on_eat(self, food) -> None:
        mult = 2 if self.double_score_timer > 0 else 1
        points = food.score * mult
        self.score = max(0, self.score + points)
        self.foods_eaten += 1
        self.combo += 1
        self.combo_timer = 2.5

        if food.food_type == "coin" or food.effect == "coin":
            self.coins += 1
            settings.coins += 1
            sound_manager.play_sfx("coin")
        else:
            sound_manager.play_sfx("eat")

        if food.food_type == "golden":
            self.golden_eaten += 1
            self.coins += 3
            settings.coins += 3
        elif food.food_type == "rare":
            self.rare_eaten += 1
            self.coins += 10
            settings.coins += 10
        elif food.food_type == "poison":
            self.poison_eaten += 1
            self._on_hit()
        elif food.effect == "speed_up":
            self.speed_eaten += 1
            self.snake.speed_multiplier = min(2.0, self.snake.speed_multiplier + 0.3)
            self.speed_boost_timer = max(self.speed_boost_timer, 8.0)
        elif food.effect == "slow_down":
            self.snake.speed_multiplier = max(0.5, self.snake.speed_multiplier - 0.3)
            self.speed_boost_timer = max(self.speed_boost_timer, 6.0)
        elif food.effect == "double_score":
            self.double_score_timer = 15.0

        if food.score > 0:
            self.snake.grow(1 if food.food_type != "rare" else 3)

        # Particles
        hx, hy = self.snake.get_head()
        self.particles.emit(
            hx * CELL_SIZE + CELL_SIZE // 2,
            hy * CELL_SIZE + CELL_SIZE // 2,
            food.color,
            count=14,
            speed=100,
        )
        settings.save()

    def _on_hit(self) -> None:
        self.shake.shake(10, 0.35)
        sound_manager.play_sfx("hurt")
        hx, hy = self.snake.get_head()
        self.particles.emit(
            hx * CELL_SIZE + CELL_SIZE // 2,
            hy * CELL_SIZE + CELL_SIZE // 2,
            RED,
            count=20,
            speed=140,
        )
        # Force a hit on snake
        if self.snake.invincible_timer <= 0 and not self.snake.shield_active:
            self.snake.lives -= 1
            if self.snake.lives <= 0:
                self.snake.alive = False
            else:
                self.snake.invincible_timer = 2.0
                while len(self.snake.body) > 3:
                    self.snake.body.pop()
        elif self.snake.shield_active:
            self.snake.shield_active = False
            self.snake.invincible_timer = 1.0

    def _trigger_game_over(self) -> None:
        self.state = "gameover"
        self.game_over = True
        sound_manager.play_sfx("lose")
        clear_game_state()
        add_record(self.score, self.coins, settings.current_map, settings.difficulty)
        add_xp(self.score // 10)
        settings.games_played += 1
        settings.total_score += self.score
        settings.save()
        achievement_manager.update_stats(deaths=1, games_played=settings.games_played)
        # Explosion
        hx, hy = self.snake.get_head()
        self.particles.emit(
            hx * CELL_SIZE + CELL_SIZE // 2,
            hy * CELL_SIZE + CELL_SIZE // 2,
            RED,
            count=40,
            speed=180,
            lifetime=1.2,
        )

    def _trigger_victory(self) -> None:
        self.state = "victory"
        self.victory = True
        sound_manager.play_sfx("win")
        clear_game_state()
        add_record(self.score, self.coins, settings.current_map, settings.difficulty)
        add_xp(self.score // 5)
        settings.save()

    def _save_current(self) -> None:
        state = {
            "valid": True,
            "score": self.score,
            "coins": self.coins,
            "level": self.level,
            "time": self.time_played,
            "lives": self.snake.lives,
            "map": settings.current_map,
            "difficulty": settings.difficulty,
        }
        save_game_state(state)

    def draw(self, surface: pygame.Surface) -> None:
        offset = self.shake.get_offset()
        # Background
        self.game_map.draw_background(surface)
        self.weather.draw(surface)

        # Game area (centered if needed)
        # For simplicity draw full grid from (0,0)
        self.game_map.draw_obstacles(surface, offset)
        self.food_mgr.draw(surface, offset)
        self.enemy_mgr.draw(surface, offset)
        self.snake.draw(surface, offset)
        self.particles.draw(surface, offset)

        self._draw_hud(surface)

        if self.state == "countdown":
            self._draw_countdown(surface)
        elif self.state == "paused":
            self._draw_pause(surface)
        elif self.state == "gameover":
            self._draw_gameover(surface)
        elif self.state == "victory":
            self._draw_victory(surface)

        for n in self.notifications:
            n.draw(surface, settings.width)

    def _draw_hud(self, surface: pygame.Surface) -> None:
        # Top bar
        bar = pygame.Surface((settings.width, 36), pygame.SRCALPHA)
        bar.fill((0, 0, 0, 160))
        surface.blit(bar, (0, 0))

        font = self.fonts["small"]
        texts = [
            f"{settings.t('score')}: {self.score}",
            f"{settings.t('record')}: {self.best_score}",
            f"{settings.t('coins')}: {self.coins}",
            f"{settings.t('lives')}: {self.snake.lives}",
            f"{settings.t('level')}: {self.level}",
            f"{settings.t('time')}: {int(self.time_played)}s",
            f"{settings.difficulty}",
        ]
        x = 10
        for t in texts:
            surf = font.render(t, True, WHITE)
            surface.blit(surf, (x, 8))
            x += surf.get_width() + 18

        if settings.show_fps:
            # FPS drawn by main
            pass

        # Active effects
        ey = 42
        if self.double_score_timer > 0:
            surface.blit(font.render(f"2x Score {self.double_score_timer:.0f}s", True, GOLD), (10, ey))
            ey += 20
        if self.snake.shield_active:
            surface.blit(font.render("Shield", True, CYAN), (10, ey))

    def _draw_countdown(self, surface: pygame.Surface) -> None:
        num = max(1, int(self.countdown) + 1)
        text = self.fonts["title"].render(str(num), True, GOLD)
        surface.blit(text, text.get_rect(center=(settings.width // 2, settings.height // 2)))

    def _draw_pause(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((settings.width, settings.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))
        title = self.fonts["large"].render(settings.t("pause"), True, WHITE)
        surface.blit(title, title.get_rect(center=(settings.width // 2, settings.height // 2 - 80)))
        for b in self.pause_buttons:
            b.draw(surface)

    def _draw_gameover(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((settings.width, settings.height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        surface.blit(overlay, (0, 0))
        title = self.fonts["title"].render(settings.t("game_over"), True, RED)
        surface.blit(title, title.get_rect(center=(settings.width // 2, settings.height // 2 - 80)))
        score_t = self.fonts["medium"].render(f"{settings.t('score')}: {self.score}", True, WHITE)
        surface.blit(score_t, score_t.get_rect(center=(settings.width // 2, settings.height // 2 - 20)))
        for b in self.gameover_buttons:
            b.draw(surface)

    def _draw_victory(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface((settings.width, settings.height), pygame.SRCALPHA)
        overlay.fill((0, 40, 0, 180))
        surface.blit(overlay, (0, 0))
        title = self.fonts["title"].render(settings.t("victory"), True, GOLD)
        surface.blit(title, title.get_rect(center=(settings.width // 2, settings.height // 2 - 80)))
        score_t = self.fonts["medium"].render(f"{settings.t('score')}: {self.score}", True, WHITE)
        surface.blit(score_t, score_t.get_rect(center=(settings.width // 2, settings.height // 2 - 20)))
        for b in self.gameover_buttons:
            b.draw(surface)
